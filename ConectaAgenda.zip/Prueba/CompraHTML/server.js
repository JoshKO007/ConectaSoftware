const express = require('express');
const Stripe = require('stripe');
const axios = require('axios');
const dotenv = require('dotenv');
const WebSocket = require('ws');

dotenv.config();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const app = express();
app.use(express.static('public'));
app.use(express.json()); 

const wss = new WebSocket.Server({ noServer: true });

wss.on('connection', (ws) => {
  console.log('Cliente conectado');

  ws.on('message', (message) => {
    console.log('Mensaje recibido: %s', message);
  });
});

const server = app.listen(3001, () => {
  console.log('Servidor HTTP corriendo en http://localhost:3001');
});

server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

app.post('/create-checkout-session', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'mxn',
          product_data: {
            name: 'Conecta y Agenda Pro',
          },
          unit_amount: 250000, 
        },
        quantity: 1,
      }],
      mode: 'payment',
      success_url: 'http://localhost:3001/success',
      cancel_url: 'http://localhost:3001/cancel',
    });

    res.json({ id: session.id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

function notificarJava(status) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ status }));
      console.log(`Notificación enviada a la aplicación Java: ${status}`);
    }
  });
}

app.get('/success', async (req, res) => {
  try {
    notificarJava('success');
    res.send('Compra exitosa, por favor regresa al programa...');
  } catch (error) {
    console.error('Error al notificar en la ruta de éxito:', error.message);
    res.status(500).send('Error al notificar.');
  }
});

app.get('/cancel', async (req, res) => {
  try {
    notificarJava('cancel');
    res.send('Compra cancelada, notificando a la aplicación Java...');
  } catch (error) {
    console.error('Error al notificar en la ruta de cancelación:', error.message);
    res.status(500).send('Error al notificar.');
  }
});
