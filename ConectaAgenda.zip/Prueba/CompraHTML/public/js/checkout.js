const stripe = Stripe('pk_test_51PykcNRucxsb5W1jQmOW7PSR2kXYPhhaKrECDbmcoyeUQFSukQr2lScD5hzA9Ysp5HZSKm0rEP53i9uELa1WC2qm00PfkFxb7E'); 

const checkoutButton = document.getElementById('checkout-button');

checkoutButton.addEventListener('click', () => {
  fetch('/create-checkout-session', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  })
  .then(response => response.json())
  .then(session => {
    return stripe.redirectToCheckout({ sessionId: session.id });
  })
  .then(result => {
    if (result.error) {
      alert(result.error.message);
    }
  })
  .catch(error => console.error('Error:', error));
});
