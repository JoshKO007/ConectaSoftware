package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class NuevaCita extends JFrame {

    private String correoE = "";
    private String sexoF = "";
    private String edadF = "";
    private String telefonoF = "";
    private boolean usuarioVerificado = false; // Verificación del usuario
    private JDateChooser dateChooser;
    private JComboBox<String> horarioComboBox;
    private String userID;

    public NuevaCita() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Nueva cita");
        setSize(600, 700); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel inicio = new JLabel("Registra una nueva cita");
        inicio.putClientProperty("FlatLaf.style", "font: bold $h2.regular.font");
        inicio.setBounds(200, 20, 350, 25);
        panel.add(inicio);

        JLabel nombre = new JLabel("Selecciona el nombre del cliente:");
        nombre.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        nombre.setBounds(40, 80, 350, 25);
        panel.add(nombre);

        RegistroBD dbManager = new RegistroBD();
        
        StringBuilder contenido = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea);
            }
        } catch (IOException o) {
            System.out.println("Error al leer el archivo de usuario: " + o.getMessage());
        }
        
        String user = contenido.toString(); 
        userID = dbManager.obtenerID(user);

        try {
            dbManager.guardarClientesEnArchivo(userID);
        } catch (IOException ex) {
            Logger.getLogger(NuevaCita.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ArrayList<String> nombresList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("clientes_" + userID + ".txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datosCliente = linea.split(",");
                if (datosCliente.length == 5) {  
                    String nombreCl = datosCliente[0].trim();
                    nombresList.add(nombreCl);
                } else {
                    System.out.println("Formato de línea incorrecto: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de clientes: " + e.getMessage());
        }     

        String[] Nombres = nombresList.toArray(new String[0]);
        JComboBox<String> nombreUS = new JComboBox<>(Nombres);
        nombreUS.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        nombreUS.setBounds(248, 80, 310, 25);
        panel.add(nombreUS);

        JButton verificar = new JButton("Verificar usuario");
        verificar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        verificar.setBounds(230, 120, 150, 25);
        panel.add(verificar);  

        JLabel datos = new JLabel("Datos de cliente");
        datos.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        datos.setBounds(245, 155, 150, 25);
        panel.add(datos);
        
        JLabel cita = new JLabel("Detalles de la cita");
        cita.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        cita.setBounds(238, 260, 150, 25);
        panel.add(cita);

        JLabel correo = new JLabel("Correo electronico:");
        correo.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        correo.setBounds(40, 180, 300, 25);
        panel.add(correo); 

        JTextField CorreoDato = new JTextField("");
        CorreoDato.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        CorreoDato.setBounds(165, 180, 200, 25);
        CorreoDato.setEditable(false);
        panel.add(CorreoDato); 

        JLabel sexo = new JLabel("Sexo:");
        sexo.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        sexo.setBounds(400, 180, 300, 25);
        panel.add(sexo); 

        JTextField sexoDato = new JTextField("");
        sexoDato.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        sexoDato.setBounds(440, 180, 100, 25);
        sexoDato.setEditable(false);
        panel.add(sexoDato); 

        JLabel edad = new JLabel("Edad:");
        edad.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        edad.setBounds(40, 220, 300, 25);
        panel.add(edad); 

        JTextField edadDato = new JTextField("");
        edadDato.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        edadDato.setBounds(80, 220, 100, 25);
        edadDato.setEditable(false);
        panel.add(edadDato); 

        JLabel telefono = new JLabel("Número de telefóno:");
        telefono.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        telefono.setBounds(200, 220, 300, 25);
        panel.add(telefono); 

        JTextField telefonoDato = new JTextField("");
        telefonoDato.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        telefonoDato.setBounds(340, 220, 200, 25);
        telefonoDato.setEditable(false);
        panel.add(telefonoDato); 

        JLabel fechaCita = new JLabel("Selecciona fecha de la cita:");
        fechaCita.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        fechaCita.setBounds(40, 300, 200, 25);
        panel.add(fechaCita);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(230, 300, 150, 25);
        
        // Establece la fecha mínima a un día después de la fecha actual
        Date hoy = new Date();
        Date diaDespues = new Date(hoy.getTime() + (1000 * 60 * 60 * 24)); // Sumar 1 día
        dateChooser.setMinSelectableDate(diaDespues);

        panel.add(dateChooser);

        JLabel horarioLabel = new JLabel("Selecciona horario de la cita:");
        horarioLabel.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        horarioLabel.setBounds(40, 340, 200, 25);
        panel.add(horarioLabel);

        horarioComboBox = new JComboBox<>();
        horarioComboBox.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        horarioComboBox.setBounds(230, 340, 150, 25);
        panel.add(horarioComboBox);

        dateChooser.addPropertyChangeListener("date", evt -> {
            if (dateChooser.getDate() != null && usuarioVerificado) {
                cargarHorariosDisponibles(dbManager);
            }
        });

        JLabel precioLabel = new JLabel("Precio de cita:");
        precioLabel.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        precioLabel.setBounds(40, 380, 200, 25);
        panel.add(precioLabel);

        JTextField precioField = new JTextField();
        precioField.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        precioField.setBounds(250, 380, 100, 25);
        panel.add(precioField);

        JLabel pesoSign = new JLabel("$");
        pesoSign.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        pesoSign.setBounds(236, 380, 20, 25);
        panel.add(pesoSign);

        JLabel anticipoLabel = new JLabel("Requiere anticipo:");
        anticipoLabel.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        anticipoLabel.setBounds(40, 420, 200, 25);
        panel.add(anticipoLabel);

        JRadioButton siButton = new JRadioButton("Sí");
        siButton.setBounds(230, 420, 50, 25);
        panel.add(siButton);

        JRadioButton noButton = new JRadioButton("No");
        noButton.setBounds(290, 420, 50, 25);
        panel.add(noButton);

        ButtonGroup anticipoGroup = new ButtonGroup();
        anticipoGroup.add(siButton);
        anticipoGroup.add(noButton);

        JLabel detallesLabel = new JLabel("Detalles de cita:");
        detallesLabel.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        detallesLabel.setBounds(40, 460, 200, 25);
        panel.add(detallesLabel);

        JTextArea detallesArea = new JTextArea();
        detallesArea.setLineWrap(true);
        detallesArea.setWrapStyleWord(true);
        detallesArea.setDocument(new JTextFieldLimit(500));
        
        JScrollPane scrollPane = new JScrollPane(detallesArea);
        scrollPane.setBounds(40, 490, 500, 100);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panel.add(scrollPane);

        JLabel contadorLabel = new JLabel("0/500");
        contadorLabel.putClientProperty("FlatLaf.style", "font: $h5.font");
        contadorLabel.setBounds(500, 595, 100, 25);
        panel.add(contadorLabel);
        
        JButton cancelar = new JButton("Cancelar");
        cancelar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        cancelar.setBounds(43, 630, 100, 25);
        panel.add(cancelar);

        cancelar.addActionListener(e -> {
            Principal PRFrame = new Principal();
            PRFrame.setVisible(true);
            dispose();
        });

        JButton registrar = new JButton("Registrar");
        registrar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        registrar.setBounds(440, 630, 100, 25);
        panel.add(registrar);

        detallesArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                contadorLabel.setText(detallesArea.getText().length() + "/500");
            }
        });

        verificar.addActionListener(e -> {
            usuarioVerificado = true;
            String seleccion = (String) nombreUS.getSelectedItem();
            try (BufferedReader reader = new BufferedReader(new FileReader("clientes_" + userID + ".txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] partes = line.split(",");
                    if (partes.length >= 5 && partes[0].trim().equals(seleccion)) {
                        telefonoF = partes[1].trim();
                        correoE = partes[2].trim();
                        sexoF = partes[3].trim();
                        edadF = partes[4].trim();
                        break;
                    }
                }
            } catch (IOException error) {
                error.printStackTrace();
            }
            CorreoDato.setText(correoE);
            sexoDato.setText(sexoF);
            edadDato.setText(edadF);
            telefonoDato.setText(telefonoF);
        });

    registrar.addActionListener(e -> {
        if (!usuarioVerificado) {
            JOptionPane.showMessageDialog(null, "Primero debe verificar el usuario.");
            return;
        }

        if (dateChooser.getDate() == null || horarioComboBox.getSelectedItem() == null || precioField.getText().isEmpty() || (!siButton.isSelected() && !noButton.isSelected()) || detallesArea.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos.");
            return;
        }

        String cliente = (String) nombreUS.getSelectedItem();
        java.sql.Date fechaCitaSQL = new java.sql.Date(dateChooser.getDate().getTime());
        String horarioSeleccionado = (String) horarioComboBox.getSelectedItem();
        String horaInicio = horarioSeleccionado.split(" - ")[0] + ":00";
        java.sql.Time horaCita = java.sql.Time.valueOf(horaInicio);

        String detalleCita = detallesArea.getText();
        int precioCita = Integer.parseInt(precioField.getText());
        int anticipo = siButton.isSelected() ? 1 : 0;

        boolean resultado = dbManager.insertarCita(userID, cliente, fechaCitaSQL, horaCita, detalleCita, precioCita, anticipo);

        if (resultado) {
            JOptionPane.showMessageDialog(null, "Cita registrada correctamente.");
        } else {
            JOptionPane.showMessageDialog(null, "Error al registrar la cita.");
        }
        dbManager.closeConnection();
        Citas PRFrame = new Citas();
        PRFrame.setVisible(true);
        dispose();
    });
    }
    
    private void cargarHorariosDisponibles(RegistroBD dbManager) {
        if (dateChooser.getDate() == null) return;

        java.sql.Date fechaSeleccionada = new java.sql.Date(dateChooser.getDate().getTime());

        ArrayList<String> horariosDisponibles = obtenerHorariosDisponibles("horarios.txt", "horariosDescanso.txt");

        ArrayList<String> horariosOcupados = dbManager.obtenerHorariosOcupados(userID, fechaSeleccionada);

        ArrayList<String> horariosOcupadosFormateados = new ArrayList<>();
        for (String horario : horariosOcupados) {
            String horarioFormato = horario.substring(0, 5);
            horariosOcupadosFormateados.add(horarioFormato);
        }

        ArrayList<String> horariosFiltrados = new ArrayList<>();
        for (String horario : horariosDisponibles) {
            String horaInicio = horario.split(" ")[0];
            if (!horariosOcupadosFormateados.contains(horaInicio)) {
                horariosFiltrados.add(horario);
            }
        }

        horarioComboBox.setModel(new DefaultComboBoxModel<>(horariosFiltrados.toArray(new String[0])));
        
    }

    private ArrayList<String> obtenerHorariosDisponibles(String archivoHorarios, String archivoDescanso) {
        HashSet<String> horariosDescanso = new HashSet<>();
        ArrayList<String> horariosDisponibles = new ArrayList<>();

        try (BufferedReader brDescanso = new BufferedReader(new FileReader(archivoDescanso))) {
            String linea;
            while ((linea = brDescanso.readLine()) != null) {
                horariosDescanso.add(linea.trim());
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de horarios de descanso: " + e.getMessage());
        }

        try (BufferedReader brHorarios = new BufferedReader(new FileReader(archivoHorarios))) {
            String linea;
            while ((linea = brHorarios.readLine()) != null) {
                if (!horariosDescanso.contains(linea.trim())) {
                    horariosDisponibles.add(linea.trim());
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de horarios: " + e.getMessage());
        }

        return horariosDisponibles;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new NuevaCita().setVisible(true);
        });
    }
}

class JTextFieldLimit extends javax.swing.text.PlainDocument {
    private final int limit;

    JTextFieldLimit(int limit) {
        this.limit = limit;
    }

    @Override
    public void insertString(int offset, String str, javax.swing.text.AttributeSet attr) throws javax.swing.text.BadLocationException {
        if (str == null) return;

        if ((getLength() + str.length()) <= limit) {
            super.insertString(offset, str, attr);
        }
    }
}
