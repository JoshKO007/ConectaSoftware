package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Usuario extends JFrame {

    private JTextField usuarioUS;
    private JPasswordField contraseñaUS;

    public Usuario() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Usuarios");
        setSize(450, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel usuario = new JLabel("Selecciona un usuario");
        usuario.putClientProperty("FlatLaf.style", "font: bold $h1.font");
        usuario.setBounds(95, 20, 300, 25);
        panel.add(usuario);

        JLabel Admin = new JLabel();
        Admin.setBounds(175, 60, 100, 100);
        ImageIcon originalIcon = new ImageIcon("imagenes/Usuario.png");
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        Admin.setIcon(resizedIcon);
        panel.add(Admin);
        
        JLabel AdminLabel = new JLabel("Administrador");
        AdminLabel.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        AdminLabel.setBounds(181, 120, 100, 100);
        panel.add(AdminLabel);
        
        JButton AdminButton = new JButton("Iniciar");
        AdminButton.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        AdminButton.setBounds(185, 180, 80, 20);
        panel.add(AdminButton);        
        
        JLabel US1 = new JLabel();
        US1.setBounds(70, 220, 80, 80);
        ImageIcon originalIcon2 = new ImageIcon("imagenes/OtroUS.png");
        Image originalImage2 = originalIcon2.getImage();
        Image resizedImage2 = originalImage2.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon2 = new ImageIcon(resizedImage2);
        US1.setIcon(resizedIcon2);
        panel.add(US1);
        
        JLabel US2 = new JLabel();
        US2.setBounds(187, 220, 80, 80);
        ImageIcon originalIcon3 = new ImageIcon("imagenes/OtroUS.png");
        Image originalImage3 = originalIcon3.getImage();
        Image resizedImage3 = originalImage3.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon3 = new ImageIcon(resizedImage3);
        US2.setIcon(resizedIcon3);
        panel.add(US2);      

        JLabel US3 = new JLabel();
        US3.setBounds(305, 220, 80, 80);
        ImageIcon originalIcon4 = new ImageIcon("imagenes/OtroUS.png");
        Image originalImage4 = originalIcon4.getImage();
        Image resizedImage4 = originalImage4.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon4 = new ImageIcon(resizedImage4);
        US3.setIcon(resizedIcon4);
        panel.add(US3);         
        
        JLabel US1Label = new JLabel("Usuario 1");
        US1Label.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US1Label.setBounds(79, 260, 100, 100);
        panel.add(US1Label);
        
        JLabel US2Label = new JLabel("Usuario 2");
        US2Label.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US2Label.setBounds(197, 260, 100, 100);
        panel.add(US2Label);  

        JLabel US3Label = new JLabel("Usuario 3");
        US3Label.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US3Label.setBounds(316, 260, 100, 100);
        panel.add(US3Label);         
        
        JButton US1Button = new JButton("Iniciar");
        US1Button.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US1Button.setBounds(68, 320, 80, 20);
        panel.add(US1Button);
        
        JButton US2Button = new JButton("Iniciar");
        US2Button.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US2Button.setBounds(186, 320, 80, 20);
        panel.add(US2Button);  
        
        JButton US3Button = new JButton("Iniciar");
        US3Button.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US3Button.setBounds(305, 320, 80, 20);
        panel.add(US3Button);  
        
        JLabel preguntaLabel = new JLabel("¿Primera vez seleccionando usuario?");
        preguntaLabel.setBounds(80, 360, 250, 25);  
        panel.add(preguntaLabel);

        JLabel linkLabel = new JLabel("Click aquí");
        linkLabel.setBounds(300, 360, 250, 25); 
        linkLabel.setForeground(Color.WHITE);
        linkLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        panel.add(linkLabel);

        linkLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                linkLabel.setText("<html><a style='text-decoration:underline; color:blue;'>Click aquí</a></html>");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                linkLabel.setText("<html><a style='text-decoration:none; color:white;'>Click aquí</a></html>");
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                Default newFrame = new Default();
                newFrame.setVisible(true);
                dispose();
                JOptionPane.showMessageDialog(null, "Si has cambiado las contraseñas estas no funcionaran.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });
        
        AdminButton.addActionListener(e -> {
            StringBuilder contenido = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        contenido.append(linea);
                    }
                } catch (IOException o) {
                }
                
            String user = contenido.toString(); 
            String input = JOptionPane.showInputDialog(null, "Ingrese la contraseña del administrador:");
            
            if (input != null && !input.isEmpty()) {
                RegistroBD dbManager = new RegistroBD();
                boolean usuarioVerificacion = dbManager.IniciarAdmin(user, input);
                if(usuarioVerificacion){
                    System.out.println("Inicio de sesión exitoso: administrador");
                    Principal newFrame = new Principal();
                    newFrame.setVisible(true);
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Error: Contraseña incorrecta para Administrador", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }                       

        });
        
        US1Button.addActionListener(e -> {
            StringBuilder contenido = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        contenido.append(linea);
                    }
                } catch (IOException o) {
                }
                
            String user = contenido.toString(); 
            String input = JOptionPane.showInputDialog(null, "Ingrese la contraseña de Usuario 1:");
            
            if (input != null && !input.isEmpty()) {
                RegistroBD dbManager = new RegistroBD();
                boolean usuarioVerificacion = dbManager.IniciarUsuario1(user, input);
                if(usuarioVerificacion){
                    System.out.println("Inicio de sesión exitoso: usuario 1");
                    Principal newFrame = new Principal();
                    newFrame.setVisible(true);
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Error: Contraseña incorrecta para Usuario 3", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }                        
        });        

        US2Button.addActionListener(e -> {
            StringBuilder contenido = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        contenido.append(linea);
                    }
                } catch (IOException o) {
                }
                
            String user = contenido.toString(); 
            String input = JOptionPane.showInputDialog(null, "Ingrese la contraseña de Usuario 2:");
            
            if (input != null && !input.isEmpty()) {
                RegistroBD dbManager = new RegistroBD();
                boolean usuarioVerificacion = dbManager.IniciarUsuario2(user, input);
                if(usuarioVerificacion){
                    System.out.println("Inicio de sesión exitoso: usuario 2");
                    Principal newFrame = new Principal();
                    newFrame.setVisible(true);                    
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Error: Contraseña incorrecta para Usuario 2", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }            
        });  
        
        US3Button.addActionListener(e -> {
            StringBuilder contenido = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        contenido.append(linea);
                    }
                } catch (IOException o) {
                }
                
            String user = contenido.toString(); 
            String input = JOptionPane.showInputDialog(null, "Ingrese la contraseña de Usuario 3:");
            
            if (input != null && !input.isEmpty()) {
                RegistroBD dbManager = new RegistroBD();
                boolean usuarioVerificacion = dbManager.IniciarUsuario3(user, input);
                if(usuarioVerificacion){
                    System.out.println("Inicio de sesión exitoso: usuario 3");
                    Principal newFrame = new Principal();
                    newFrame.setVisible(true);                    
                    dispose();
                }else{
                    JOptionPane.showMessageDialog(null, "Error: Contraseña incorrecta para Usuario 3", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });        
    }

    
    public static void main(String[] args) {
        System.setProperty( "apple.awt.application.appearance", "system" );
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");

        SwingUtilities.invokeLater(() -> {
            new Usuario().setVisible(true);
        });
    }
}
