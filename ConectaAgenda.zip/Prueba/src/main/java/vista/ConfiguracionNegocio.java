package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.*;

public class ConfiguracionNegocio extends JFrame {

    public ConfiguracionNegocio() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Configuración del Negocio");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel inicio = new JLabel("Configura tu negocio");
        inicio.putClientProperty("FlatLaf.style", "font: bold $h2.regular.font");
        inicio.setBounds(200, 20, 350, 25);
        panel.add(inicio);

        JLabel nombre = new JLabel("Ingresa el nombre de tu negocio:");
        nombre.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        nombre.setBounds(40, 80, 350, 25);
        panel.add(nombre);

        JTextField nombreUS = new JTextField();
        nombreUS.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        nombreUS.setBounds(248, 80, 310, 25);
        panel.add(nombreUS);

        JLabel tipo = new JLabel("¿Qué tipo de negocio tienes?:");
        tipo.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        tipo.setBounds(40, 120, 350, 25);
        panel.add(tipo);

        String[] tiposNegocio = {
            "Selecciona un tipo de negocio", 
            "Consultorio Médico", "Clínica Dental", "Spa y Bienestar", "Estudio de Yoga", 
            "Centro de Terapia Física", "Oficina de Abogado", "Agencia de Viajes", "Restaurante", 
            "Cafetería", "Barbería", "Salón de Belleza", "Tienda de Ropa", "Librería", "Gimnasio", 
            "Escuela de Música", "Academia de Idiomas", "Centro de Entrenamiento Personal", 
            "Servicio de Mantenimiento", "Taller de Reparación de Autos", "Oficina de Arquitectura", 
            "Agencia de Publicidad", "Centro de Computación", "Estudio de Fotografía", "Tienda de Electrónica", 
            "Farmacia", "Consultora de Negocios", "Galería de Arte", "Cine", "Centro de Jardinería", 
            "Salón de Eventos", "Tienda de Mascotas", "Oficina de Recursos Humanos", "Centro de Capacitación", 
            "Servicio de Catering", "Centro de Salud", "Llantera", "Tienda de Muebles", "Taller de Costura", 
            "Servicio de Limpieza", "Agencia Inmobiliaria", "Oficina de Diseño Gráfico", "Escuela de Arte", 
            "Comida Rápida", "Centro de Veterinaria", "Tienda de Juguetes", "Estudio de Diseño Web", 
            "Academia de Pintura", "Otro"
        };

        JComboBox<String> tipoUS = new JComboBox<>(tiposNegocio);
        tipoUS.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        tipoUS.setBounds(248, 120, 230, 25);
        panel.add(tipoUS);

        JLabel dias = new JLabel("Selecciona los días que está abierto tu negocio:");
        dias.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        dias.setBounds(147, 160, 400, 25);
        panel.add(dias);

        JPanel diasPanel = new JPanel();
        diasPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10)); 
        diasPanel.setBounds(50, 200, 500, 80); 
        panel.add(diasPanel);

        JCheckBox lunes = new JCheckBox("Lunes");
        lunes.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(lunes);

        JCheckBox martes = new JCheckBox("Martes");
        martes.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(martes);

        JCheckBox miercoles = new JCheckBox("Miércoles");
        miercoles.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(miercoles);

        JCheckBox jueves = new JCheckBox("Jueves");
        jueves.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(jueves);

        JCheckBox viernes = new JCheckBox("Viernes");
        viernes.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(viernes);

        JCheckBox sabado = new JCheckBox("Sábado");
        sabado.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(sabado);

        JCheckBox domingo = new JCheckBox("Domingo");
        domingo.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        diasPanel.add(domingo);
        
        JLabel horarioE = new JLabel("Selecciona el horario de apertura:");
        horarioE.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        horarioE.setBounds(140, 280, 250, 25);
        panel.add(horarioE);
        
        String[] horarioEntrada = {
            "5:00","6:00", "7:00", "8:00","9:00", "10:00", "11:00", "12:00",
            "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00",
            "21:00", "22:00", "23:00"
        };
        
        JComboBox<String> horarioEntradaUS = new JComboBox<>(horarioEntrada);
        horarioEntradaUS.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        horarioEntradaUS.setBounds(350, 280, 100, 25);
        panel.add(horarioEntradaUS);
        
        JLabel horarioC = new JLabel("Selecciona el horario de cierre:");
        horarioC.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        horarioC.setBounds(140, 320, 250, 25);
        panel.add(horarioC);
        
        String[] horarioSalida = {
            "5:00","6:00", "7:00", "8:00","9:00", "10:00", "11:00", "12:00",
            "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00",
            "21:00", "22:00", "23:00"
        };
        
        JComboBox<String> horarioSalidaUS = new JComboBox<>(horarioSalida);
        horarioSalidaUS.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        horarioSalidaUS.setBounds(350, 320, 100, 25);
        panel.add(horarioSalidaUS);        
        
        JLabel Intervalos = new JLabel("Selecciona el intervalo de tiempo entre citas: ");
        Intervalos.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        Intervalos.setBounds(100, 360, 300, 25);
        panel.add(Intervalos);
        
        String[] intervalos = {
            "15 minutos", "30 minutos", "45 minutos", "1 hora", "2 horas"
        };

        JComboBox<String> intervalosUS = new JComboBox<>(intervalos);
        intervalosUS.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        intervalosUS.setBounds(380, 360, 110, 25);
        panel.add(intervalosUS);          
        
        JButton continuar = new JButton("Continuar");
        continuar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        continuar.setBounds(250, 420, 100, 25);
        panel.add(continuar); 
        
        continuar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder contenido = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                        String linea;
                        while ((linea = reader.readLine()) != null) {
                            contenido.append(linea);
                        }
                    } catch (IOException o) {
                }
                String user = contenido.toString(); 
                String nombreNegocio = nombreUS.getText();
                String tipoNegocio = tipoUS.getSelectedItem().toString();
                boolean lunesSelected = lunes.isSelected();
                boolean martesSelected = martes.isSelected();
                boolean miercolesSelected = miercoles.isSelected();
                boolean juevesSelected = jueves.isSelected();
                boolean viernesSelected = viernes.isSelected();
                boolean sabadoSelected = sabado.isSelected();
                boolean domingoSelected = domingo.isSelected();
                String horarioApertura = horarioEntradaUS.getSelectedItem().toString() + ":00";
                String horarioCierre = horarioSalidaUS.getSelectedItem().toString() + ":00";
                String intervaloTiempo = intervalosUS.getSelectedItem().toString();
                

                RegistroBD dbManager = new RegistroBD();
                boolean exito = dbManager.insertarNegocio(nombreNegocio, tipoNegocio, lunesSelected, martesSelected, miercolesSelected, juevesSelected, viernesSelected, sabadoSelected, domingoSelected, horarioApertura, horarioCierre, intervaloTiempo, user);
                if (exito) {
                    JOptionPane.showMessageDialog(null, "¡Negocio registrado exitosamente!");
                    Usuario newFrame = new Usuario();
                    newFrame.setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al registrar el negocio.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ConfiguracionNegocio().setVisible(true);
        });
    }
}
