package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NuevoCliente extends JFrame {

    private JPanel ClientesPanel;

    public NuevoCliente() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");
            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Component.arc", 999);
            UIManager.put("Button.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Conecta y Agenda");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(null);
        add(panel);
        
        JLabel Perfil = new JLabel();
        Perfil.setBounds(25, 5, 100, 100);
        ImageIcon originalIcon = new ImageIcon("imagenes/Hombre.png");
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(85, 85, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        Perfil.setIcon(resizedIcon);
        panel.add(Perfil);
        
        JLabel Nombre = new JLabel("Nombre completo:");
        Nombre.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Nombre.setBounds(120, 1, 260, 60);
        panel.add(Nombre);  
        
        JTextField NombreUS = new JTextField();
        NombreUS.putClientProperty("FlatLaf.style", "font: bold $h5.font");
        NombreUS.setBounds(120, 45, 240, 25);
        panel.add(NombreUS);  
        
        JLabel Edad = new JLabel("Edad:");
        Edad.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Edad.setBounds(120, 60, 260, 60);
        panel.add(Edad);  
        
        JTextField EdadUS = new JTextField();
        EdadUS.putClientProperty("FlatLaf.style", "font: bold $h5.font");
        EdadUS.setBounds(170, 78, 40, 25);
        panel.add(EdadUS);  
        
        JLabel Correo = new JLabel("Correo:");
        Correo.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Correo.setBounds(45, 90, 260, 60);
        panel.add(Correo);  
        
        JTextField CorreoUS = new JTextField();
        CorreoUS.putClientProperty("FlatLaf.style", "font: bold $h5.font");
        CorreoUS.setBounds(120, 110, 240, 25);
        panel.add(CorreoUS); 
        
        JLabel Telefono = new JLabel("Teléfono:");
        Telefono.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Telefono.setBounds(45, 130, 260, 60);
        panel.add(Telefono);  
        
        JTextField TelefonoUS = new JTextField();
        TelefonoUS.putClientProperty("FlatLaf.style", "font: bold $h5.font");
        TelefonoUS.setBounds(120, 148, 240, 25);
        panel.add(TelefonoUS); 
        
        JLabel sexo = new JLabel("Sexo:");
        sexo.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        sexo.setBounds(45, 170, 260, 60);
        panel.add(sexo);  
        
        String[] sexoArray = {"Hombre", "Mujer"};
        
        JComboBox sexoUS = new JComboBox(sexoArray);
        sexoUS.putClientProperty("FlatLaf.style", "font: bold $h5.font");
        sexoUS.setBounds(120, 188, 240, 25);
        panel.add(sexoUS);         
        
        JButton Aceptar = new JButton("Agregar cliente");
        Aceptar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        Aceptar.setBounds(35, 230, 130, 25);
        panel.add(Aceptar);
        
        JButton Cancelar = new JButton("Cancelar");
        Cancelar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        Cancelar.setBounds(230, 230, 130, 25);
        panel.add(Cancelar);
        
        Aceptar.addActionListener(e -> {
            StringBuilder contenido = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        contenido.append(linea);
                    }
                } catch (IOException o) {
                }
                
            String user = contenido.toString(); 
            
            RegistroBD dbManager = new RegistroBD();
            String userID = dbManager.obtenerID(user);
            String nombre = NombreUS.getText();
            String telefono = TelefonoUS.getText();
            String correo = CorreoUS.getText();
            String sexoIm = (String) sexoUS.getSelectedItem();
            int edadIM = Integer.parseInt(EdadUS.getText());

            boolean ingresoCliente = dbManager.insertarCliente(userID, nombre, telefono, correo, sexoIm, edadIM);
            if(ingresoCliente){
                try {
                    System.out.println("Cliente registrado");
                    JOptionPane.showMessageDialog(null, "Usuario registrado satisfactoriamente");
                    Clientes newFrame = new Clientes();
                    newFrame.setVisible(true);
                    dispose();
                } catch (IOException ex) {
                    Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
                JOptionPane.showMessageDialog(null, "Error al registrar usuario", "Error", JOptionPane.ERROR_MESSAGE);
            }
                                

        });
        
        Cancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Clientes CSFrame = new Clientes();
                    CSFrame.setVisible(true); 
                    dispose();
                } catch (IOException ex) {
                    Logger.getLogger(NuevoCliente.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NuevoCliente().setVisible(true));
    }
}
