package vista;

import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import Modelo.*;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class GestionarHorarios extends JFrame {
    
    private JPanel checkBoxPanel; 
    private List<JCheckBox> checkBoxes;

    public GestionarHorarios() {
        configurarEstilos();
        setTitle("Gestionar Horarios");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        add(panel);

        JLabel titulo = new JLabel("Selecciona los horarios de descanso", JLabel.CENTER);
        titulo.putClientProperty("FlatLaf.style", "font: bold $h2.regular.font");
        panel.add(titulo, BorderLayout.NORTH); 

        checkBoxPanel = new JPanel();
        GridBagLayout gridBagLayout = new GridBagLayout();
        checkBoxPanel.setLayout(gridBagLayout);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        StringBuilder contenido = new StringBuilder();                          
        try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al leer el archivo de usuario", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Termina la ejecución del método en caso de error
        }
        
        String user = contenido.toString(); 
        RegistroBD dbManager = new RegistroBD();
        String userID = dbManager.obtenerID(user);
        String apertura = dbManager.obtenerHorarioApertura(userID);
        String cierre = dbManager.obtenerHorarioCierre(userID);
        String intervalo = dbManager.obtenerIntervalo(userID);

        GenerarHorarios generador = new GenerarHorarios();
        checkBoxes = generador.generarHorariosCheck(apertura, cierre, intervalo); 

        for (int i = 0; i < checkBoxes.size(); i++) {
            gbc.gridx = i % 2; 
            gbc.gridy = i / 2; 
            checkBoxPanel.add(checkBoxes.get(i), gbc);
        }

        JScrollPane scrollPane = new JScrollPane(checkBoxPanel);
        panel.add(scrollPane, BorderLayout.CENTER); 

        JButton mostrarSeleccionButton = new JButton("Guardar horarios");
        mostrarSeleccionButton.setPreferredSize(new Dimension(200, 40));
        mostrarSeleccionButton.addActionListener(e -> {
            mostrarHorariosDescanso(); 
            Principal PFrame = new Principal(); 
            PFrame.setVisible(true);
            dispose();
        });

        JPanel buttonPanel = new JPanel(new BorderLayout());

        JButton cancelarButton = new JButton("Cancelar");
        cancelarButton.setPreferredSize(new Dimension(100, 30));
        cancelarButton.addActionListener(e -> {
            Principal PFrame = new Principal(); 
            PFrame.setVisible(true);
            dispose();
        });
        
        buttonPanel.add(cancelarButton, BorderLayout.WEST);
        buttonPanel.add(mostrarSeleccionButton, BorderLayout.EAST);

        panel.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void mostrarHorariosDescanso() {
        StringBuilder seleccionados = new StringBuilder();
        
        for (JCheckBox checkBox : checkBoxes) {
            if (checkBox.isSelected()) {
                seleccionados.append(checkBox.getText()).append("\n");
            }
        }
        
        JOptionPane.showMessageDialog(this, seleccionados.toString(), "Horarios de Descanso", JOptionPane.INFORMATION_MESSAGE);
        
        try (FileWriter writer = new FileWriter("horariosDescanso.txt")) {
            writer.write(seleccionados.toString());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar los horarios de descanso.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GestionarHorarios().setVisible(true);
        });
    }
}
