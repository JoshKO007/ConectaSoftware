package vista;

import Modelo.GenerarHorarios;
import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import org.json.JSONObject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.List;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Principal extends JFrame {

    private JLabel horaLabel;
    private JLabel climaLabel;
    private JPanel climaPanel;
    private JPanel citasPanel;
    private JLabel imagenClimaLabel;
    private static final String API_URL = "https://api.open-meteo.com/v1/forecast?latitude=19.4326&longitude=-99.1332&current_weather=true"; 

    private double temperaturaActual = 0;
    private String condicionClimatica = "";

    
    public Principal() {
        configurarEstilos();
        inicializarComponentes();
        actualizarHora();
        actualizarClima();
        generarHorarios();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");
            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Conecta y Agenda");
        setSize(1000, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(null);
        add(panel);

        JPanel bienvenidaPanel = new JPanel();
        bienvenidaPanel.setBounds(40, 100, 500, 100);
        bienvenidaPanel.setBackground(new Color(64, 64, 79, 200));
        bienvenidaPanel.setLayout(new BorderLayout());
        bienvenidaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JLabel mensajeBienvenida = new JLabel("¡Bienvenido a Conecta y Agenda!", SwingConstants.CENTER);
        mensajeBienvenida.setForeground(Color.WHITE);
        mensajeBienvenida.setFont(new Font("Arial", Font.BOLD, 24));
        bienvenidaPanel.add(mensajeBienvenida, BorderLayout.CENTER);

        panel.add(bienvenidaPanel);

        climaPanel = new JPanel();
        climaPanel.setBounds(560, 100, 400, 100);
        climaPanel.setLayout(null);
        climaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        
        panel.add(climaPanel);

        horaLabel = new JLabel("Hora: --:--:--");
        horaLabel.setForeground(Color.WHITE);
        horaLabel.setFont(new Font("Arial", Font.BOLD, 24));
        horaLabel.setBounds(30, 10, 200, 40);
        climaPanel.add(horaLabel);

        climaLabel = new JLabel("Clima: -- °C");
        climaLabel.setForeground(Color.WHITE);
        climaLabel.setFont(new Font("Arial", Font.BOLD, 24));
        climaLabel.setBounds(30, 50, 200, 40);
        climaPanel.add(climaLabel);

        imagenClimaLabel = new JLabel();
        imagenClimaLabel.setBounds(260, 10, 100, 80);
        climaPanel.add(imagenClimaLabel);

        citasPanel = new JPanel();
        citasPanel.setBounds(40, 282, 630, 450);
        citasPanel.setLayout(new BorderLayout());
        citasPanel.setBackground(new Color(64, 64, 79, 200));
        citasPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        panel.add(citasPanel);
        
        JScrollPane scrollPane2 = new JScrollPane(citasPanel);
        scrollPane2.setBounds(40, 282, 630, 450); 
        scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(scrollPane2);

        JPanel citasProximasPanel = new JPanel();
        citasProximasPanel.setBounds(40, 250, 630, 35); // Ubicación y tamaño igual al original en citasPanel
        citasProximasPanel.setBackground(Color.DARK_GRAY);
        citasProximasPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        citasProximasPanel.setLayout(new FlowLayout());

        JLabel labelProxima = new JLabel("Citas próximas");
        labelProxima.setForeground(Color.WHITE);
        labelProxima.setFont(new Font("Arial", Font.BOLD, 18));
        citasProximasPanel.add(labelProxima);

        // Agrega el panel "Citas Próximas" al panel principal
        panel.add(citasProximasPanel);
        
        JPanel clientesPanel = new JPanel();
        clientesPanel.setLayout(new BoxLayout(clientesPanel, BoxLayout.Y_AXIS));
        clientesPanel.setBackground(new Color(64, 64, 79, 200));
        clientesPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        clientesPanel.setBounds(700, 280, 260, 270); 

        JPanel panelClientesSuperior = new JPanel();
        panelClientesSuperior.setLayout(new FlowLayout());
        panelClientesSuperior.setPreferredSize(new Dimension(260, 37));
        panelClientesSuperior.setBackground(Color.DARK_GRAY);
        panelClientesSuperior.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(panelClientesSuperior);
        panelClientesSuperior.setBounds(701, 250, 258, 37);

        JLabel labelClientes = new JLabel("Clientes");
        labelClientes.setForeground(Color.WHITE);
        labelClientes.setFont(new Font("Arial", Font.BOLD, 18));
        panelClientesSuperior.add(labelClientes);

        JScrollPane scrollPane = new JScrollPane(clientesPanel);
        scrollPane.setBounds(700, 283, 260, 230); 
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        panel.add(scrollPane);

        RegistroBD dbManager = new RegistroBD();
        StringBuilder contenido = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea);
            }
        } catch (IOException o) {
            System.out.println("Error al leer usuario.txt: " + o.getMessage());
        }

        String user = contenido.toString(); 
        String userID = dbManager.obtenerID(user);

        try (BufferedReader reader = new BufferedReader(new FileReader("clientes_" + userID + ".txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] datosCliente = linea.split(",");  

                if (datosCliente.length == 5) {  
                    String nombre = datosCliente[0].trim();
                    String sexo = datosCliente[3].trim();

                    clientesPanel.add(new PanelClientePrincipal(nombre, sexo));
                } else {
                    System.out.println("Formato de línea incorrecto: " + linea);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de clientes: " + e.getMessage());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea);
            }
        } catch (IOException o) {
            System.out.println("Error al leer el archivo de usuario: " + o.getMessage());
        }

        List<String[]> citas = dbManager.obtenerCitasPorUsuario(userID);

        for (String[] cita : citas) {
            String cliente = cita[0];
            String fecha = cita[1];
            String detalles = cita[2];
            String precio = cita[3];
            String hora = cita[4];
            String anticipo = cita[5];

            citasPanel.setLayout(new BoxLayout(citasPanel, BoxLayout.Y_AXIS)); 
            citasPanel.add(new PanelCitaPrincipal(cliente, fecha, detalles, precio, hora, anticipo));

        }

        JButton CambiarUS = new JButton("<html><div style='text-align: center;'>Cambiar<br>usuario</div></html>");
        CambiarUS.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        CambiarUS.setBounds(59, 5, 200, 70);
        CambiarUS.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(CambiarUS);
        
        CambiarUS.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Usuario USFrame = new Usuario();
                USFrame.setVisible(true);
                dispose(); 
            }
        });

        JButton Clientes = new JButton("<html><div style='text-align: center;'>Gestión<br>de clientes</div></html>");
        Clientes.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Clientes.setBounds(259, 5, 200, 70);
        Clientes.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(Clientes);

        Clientes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Clientes CSFrame = new Clientes();
                    CSFrame.setVisible(true); 
                    dispose();
                } catch (IOException ex) {
                    Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        JButton Negocio = new JButton("<html><div style='text-align: center;'>Gestión<br>de negocio</div></html>");
        Negocio.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Negocio.setBounds(459, 5, 200, 70);
        Negocio.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(Negocio);

        Negocio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Por favor vuelve a seleccionar las opciones vacias", "Advertencia", JOptionPane.WARNING_MESSAGE);
                EditarNegocio ENFrame = new EditarNegocio();
                ENFrame.setVisible(true);
                dispose();
            }
        });
        
        JButton Configuracion = new JButton("<html><div style='text-align: center;'>Configuración</div></html>");
        Configuracion.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Configuracion.setBounds(659, 5, 200, 70);
        Configuracion.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(Configuracion);
        
        Configuracion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ConfiguracionInicio ENFrame = new ConfiguracionInicio();
                ENFrame.setVisible(true);
                dispose();
            }
        });

        JButton Perfil = new JButton();
        Perfil.setBounds(858, 5, 80, 70);
        ImageIcon originalIcon = new ImageIcon("imagenes/Usuario.png");
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        Perfil.setIcon(resizedIcon);
        Perfil.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(Perfil);
        
        JButton consuCitas = new JButton("Ver todas las citas");
        consuCitas.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        consuCitas.setBounds(700, 530, 260, 60);
        consuCitas.putClientProperty( "JButton.buttonType", "roundRect" );
        panel.add(consuCitas);
        
        consuCitas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Citas GEFrame = new Citas();
                GEFrame.setVisible(true);
                dispose();
            }
        });
        
        JButton GesHor = new JButton("Gestionar horarios");
        GesHor.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        GesHor.setBounds(700, 600, 260, 60);
        GesHor.putClientProperty( "JButton.buttonType", "roundRect" );
        panel.add(GesHor);
        
        GesHor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GestionarHorarios GEFrame = new GestionarHorarios();
                GEFrame.setVisible(true);
                dispose();
            }
        });
        
        JButton Nueva = new JButton("Nueva Cita");
        Nueva.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Nueva.setBounds(700, 670, 260, 60);
        Nueva.putClientProperty( "JButton.buttonType", "roundRect" );
        panel.add(Nueva);   
        
        Nueva.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                NuevaCita NCFrame = new NuevaCita();
                NCFrame.setVisible(true);
                dispose();
            }
        });
        
        String Licenciatext = dbManager.obtenerLicencia(userID);
        JLabel Licencia = new JLabel("Licencia: " + Licenciatext);
        Licencia.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Licencia.setBounds(40, 720, 400, 60);
        panel.add(Licencia);  
        
        JButton DashBoard = new JButton("DashBoard");
        DashBoard.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        DashBoard.setBounds(800, 740, 150, 30);
        panel.add(DashBoard); 
        
        DashBoard.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DashBoard DBFrame = new DashBoard();
                DBFrame.setVisible(true);
                dispose();
            }
        });
    }

    private void actualizarHora() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Date now = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                horaLabel.setText("Hora: " + sdf.format(now));

                int hora = now.getHours();
                Color colorFondo;

                if (hora >= 0 && hora < 5) {
                    colorFondo = new Color(10, 10, 20);
                } else if (hora >= 5 && hora < 12) {
                    colorFondo = new Color(75, 0, 130);
                } else if (hora >= 12 && hora < 17) {
                    colorFondo = new Color(135, 206, 235);
                } else {
                    colorFondo = new Color(0, 0, 139);
                }

                if (temperaturaActual <= 0) {
                    colorFondo = colorFondo.brighter();
                } else if (temperaturaActual >= 30) {
                    colorFondo = colorFondo.darker();
                }

                climaPanel.setBackground(colorFondo);
                actualizarImagenClima();
            }
        }, 0, 1000);
    }

    private void actualizarClima() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    URL url = new URL(API_URL);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();

                    JSONObject json = new JSONObject(response.toString());
                    JSONObject currentWeather = json.getJSONObject("current_weather");
                    temperaturaActual = currentWeather.getDouble("temperature");
                    int weatherCode = currentWeather.getInt("weathercode");

                    String[] weatherDescriptions = {"Clear sky", "Mainly clear", "Partly cloudy", "Overcast", "Fog", "Drizzle", "Rain", "Snow", "Thunderstorm"};

                    if (weatherCode >= 0 && weatherCode < weatherDescriptions.length) {
                        condicionClimatica = weatherDescriptions[weatherCode];
                    } else {
                        condicionClimatica = "Clima desconocido"; 
                    }


                    climaLabel.setText(String.format("Clima: %.1f °C", temperaturaActual));

                } catch (Exception e) {
                    climaLabel.setText("Clima: Error");
                    e.printStackTrace();
                }
            }
        }, 0, 1800000);
    }

    private void actualizarImagenClima() {
        String imagenPath;
        if (condicionClimatica.toLowerCase().contains("nublado")) {
            int hora = Integer.parseInt(horaLabel.getText().substring(6, 8));
            if (hora >= 6 && hora < 18) {
                imagenPath = "imagenes/SolNube.png";
            } else {
                imagenPath = "imagenes/LunaNube.png";
            }
        } else if (condicionClimatica.toLowerCase().contains("lluvia")) {
            imagenPath = "imagenes/Nube.png";
        } else {
            int hora = Integer.parseInt(horaLabel.getText().substring(6, 8));
            if (hora >= 6 && hora < 18) {
                imagenPath = "imagenes/Sol.png";
            } else {
                imagenPath = "imagenes/Luna.png";
            }
        }

        ImageIcon imagenClimaIcon = new ImageIcon(imagenPath);
        Image imagenClima = imagenClimaIcon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        imagenClimaLabel.setIcon(new ImageIcon(imagenClima));
    }

private void generarHorarios() {
    GenerarHorarios generador = new GenerarHorarios();
    File archivoHorarios = new File("Horarios.txt"); // Cambia "Horarios.txt" por la ruta deseada

    // Verificar si el archivo existe
    if (!archivoHorarios.exists()) {
        try {
            // Si no existe, se crea el archivo
            archivoHorarios.createNewFile();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al crear el archivo de horarios", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Termina la ejecución si no se puede crear el archivo
        }
    }

    // Verificar si el archivo está vacío
    if (archivoHorarios.length() > 0) {
        // Si el archivo no está vacío, no hacer nada
        return;
    }

    // Leer el archivo de usuario
    StringBuilder contenido = new StringBuilder();                          
    try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
        String linea;
        while ((linea = reader.readLine()) != null) {
            contenido.append(linea);
        }
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(null, "Error al leer el archivo de usuario", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Termina la ejecución del método en caso de error
    }
        
    String user = contenido.toString(); 
    RegistroBD dbManager = new RegistroBD();
    String userID = dbManager.obtenerID(user);
    String apertura = dbManager.obtenerHorarioApertura(userID);
    String cierre = dbManager.obtenerHorarioCierre(userID);
    String intervalo = dbManager.obtenerIntervalo(userID);
    
    // Generar horarios como cadenas en lugar de JCheckBox
    List<String> horarios = generador.generarHorarios(apertura, cierre, intervalo);

    // Imprimir los horarios generados en la consola
    if (!horarios.isEmpty()) {
        for (String horario : horarios) {
            System.out.println("Horario generado: " + horario); // Imprimir en consola
        }

        // Guardar los horarios en el archivo "Horarios.txt"
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivoHorarios))) {
            for (String horario : horarios) {
                writer.write(horario);
                writer.newLine();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al guardar los horarios", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

        
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Principal().setVisible(true));
    }
}
