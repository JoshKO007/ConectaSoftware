package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class Inicio extends JFrame {

    private JTextField usuarioUS;
    private JPasswordField contraseñaUS;

    public Inicio() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Iniciar sesión");
        setSize(300, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel usuario = new JLabel("Usuario");
        usuario.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        usuario.setBounds(123, 50, 150, 25);
        panel.add(usuario);

        usuarioUS = new JTextField();
        usuarioUS.putClientProperty("FlatLaf.style", "font: $h4.font");
        usuarioUS.setHorizontalAlignment(JTextField.CENTER);
        usuarioUS.setBounds(50, 73, 200, 25);
        panel.add(usuarioUS);

        JLabel contraseña = new JLabel("Contraseña");
        contraseña.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        contraseña.setBounds(107, 113, 120, 25);
        panel.add(contraseña);

        contraseñaUS = new JPasswordField();
        contraseñaUS.putClientProperty("FlatLaf.style", "font: $h4.font");
        contraseñaUS.setHorizontalAlignment(JTextField.CENTER);
        contraseñaUS.setBounds(74, 136, 150, 25);
        panel.add(contraseñaUS);

        JLabel ojitoLabel = new JLabel("🔒");
        ojitoLabel.setBounds(230, 136, 30, 25);
        ojitoLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        ojitoLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        ojitoLabel.addMouseListener(new MouseAdapter() {
            private boolean passwordVisible = false;

            @Override
            public void mouseClicked(MouseEvent e) {
                passwordVisible = !passwordVisible;
                if (passwordVisible) {
                    contraseñaUS.setEchoChar((char) 0); 
                    ojitoLabel.setText("🔓"); 
                } else {
                    contraseñaUS.setEchoChar('*'); 
                    ojitoLabel.setText("🔒"); 
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                ojitoLabel.setForeground(Color.YELLOW); 
            }

            @Override
            public void mouseExited(MouseEvent e) {
                ojitoLabel.setForeground(Color.WHITE); 
            }
        });
        panel.add(ojitoLabel);

        JButton aceptar = new JButton("Iniciar Sesión");
        aceptar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        aceptar.setBounds(90, 180, 120, 25);
        panel.add(aceptar);

        aceptar.addActionListener(e -> IniciarSesion());
        

        JLabel nuevoU = new JLabel("¿Aún no tienes una cuenta?");
        nuevoU.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        nuevoU.setBounds(65, 230, 190, 25);
        panel.add(nuevoU);

        JButton nuevo = new JButton("Regístrate Aquí");
        nuevo.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        nuevo.setBounds(85, 250, 130, 25);
        panel.add(nuevo);
        

        nuevo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Registro registroFrame = new Registro();
                registroFrame.setVisible(true);
                dispose(); 
            }
        });
    }


    private void IniciarSesion() {
    String usuario = usuarioUS.getText().trim();
    String contraseña = new String(contraseñaUS.getPassword()).trim();

    RegistroBD dbManager = new RegistroBD();
    boolean exito = dbManager.IniciarSesion(usuario, contraseña);

    if (exito) {
        String userID = dbManager.obtenerID(usuario); 
        String licencia = dbManager.obtenerLicencia(userID); 

        String mensajeLicencia;
        if (licencia == null) {
            mensajeLicencia = "No se encontró licencia para el usuario.";
            SinLicencia newFrame = new SinLicencia();
            newFrame.setVisible(true);
            this.dispose();
        } else if (licencia.equals("0")) {
            mensajeLicencia = "Sin licencia";
            SinLicencia newFrame = new SinLicencia();
            newFrame.setVisible(true);
            this.dispose();
        } else if (licencia.equals("1")) {
            mensajeLicencia = "Prueba realizada. Te invitamos a comprar el producto";
            SinLicencia newFrame = new SinLicencia();
            newFrame.setVisible(true);
            this.dispose();
        } else if (licencia.length() == 20) {
            boolean esta = dbManager.usuarioEnNegocios(userID);
            if(esta){
                mensajeLicencia = "Pro";
                Usuario newFrame = new Usuario();
                newFrame.setVisible(true);
                this.dispose();
            }else{
                mensajeLicencia = "Pro";
                ConfiguracionNegocio newFrame = new ConfiguracionNegocio();
                newFrame.setVisible(true);
                this.dispose();
            }
        } else if (licencia.length() == 10) {
            boolean esta = dbManager.usuarioEnNegocios(userID);
            if(esta){
                mensajeLicencia = "Prueba gratuita";
                Usuario newFrame = new Usuario();
                newFrame.setVisible(true);
                this.dispose();
            }else{
                mensajeLicencia = "Prueba gratuita";
                ConfiguracionNegocio newFrame = new ConfiguracionNegocio();
                newFrame.setVisible(true);
                this.dispose();
            }
        } else {
            mensajeLicencia = "Licencia desconocida";
            SinLicencia newFrame = new SinLicencia();
            newFrame.setVisible(true);
            this.dispose();
        }

        JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso.\n" + mensajeLicencia, "Éxito", JOptionPane.INFORMATION_MESSAGE);
        
        if (usuario != null && !usuario.isEmpty()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("usuario.txt"))) {
                writer.write(usuario);
            } catch (IOException e) {
                e.printStackTrace(); 
            }
        }
        
    } else {
        JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrecto.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    dbManager.closeConnection();
    }
    

    
    public static void main(String[] args) {
        System.setProperty( "apple.awt.application.appearance", "system" );
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");

        SwingUtilities.invokeLater(() -> {
            new Inicio().setVisible(true);
        });
    }
}
