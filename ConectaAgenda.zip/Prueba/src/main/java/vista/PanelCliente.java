package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PanelCliente extends JPanel {

    private JLabel lblNombre;
    private JLabel lblTelefono;
    private JLabel lblCorreo;
    private JLabel lblSexo;
    private JLabel lblEdad;
    private JLabel lblEditar;
    private JLabel lblBorrar;
    private JLabel lblImagenUsuario;

    public PanelCliente(String nombreCompleto, String telefono, String correo, String sexo, int edad) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        setBackground(new Color(50, 50, 70, 200));
        setPreferredSize(new Dimension(600, 120));

        JPanel panelImagen = new JPanel();
        panelImagen.setPreferredSize(new Dimension(100, 100));
        panelImagen.setLayout(new GridBagLayout());
        panelImagen.setBackground(new Color(50, 50, 70, 200));

        lblImagenUsuario = new JLabel();
        lblImagenUsuario.setPreferredSize(new Dimension(80, 80));
        lblImagenUsuario.setIcon(crearImagenCircular(sexo));
        panelImagen.add(lblImagenUsuario, new GridBagConstraints());

        String[] partesNombre = nombreCompleto.split(" ", 3); 
        String nombre = "Nombre: " + partesNombre[0] + " " + partesNombre[1];
        String apellido = partesNombre.length > 2 ? partesNombre[2] : ""; 

        lblNombre = new JLabel("<html>" + nombre + "<br>" + apellido + "</html>");
        lblNombre.setForeground(Color.WHITE);
        
        lblTelefono = new JLabel("Teléfono: " + telefono);
        lblTelefono.setForeground(Color.WHITE);
        lblCorreo = new JLabel("Correo: " + correo);
        lblCorreo.setForeground(Color.WHITE);
        lblSexo = new JLabel("Sexo: " + sexo);
        lblSexo.setForeground(Color.WHITE);
        lblEdad = new JLabel("Edad: " + edad);
        lblEdad.setForeground(Color.WHITE);
        
        JPanel panelDatos = new JPanel();
        panelDatos.setLayout(new GridLayout(3, 2));
        panelDatos.setBackground(new Color(50, 50, 70, 200));
        panelDatos.add(lblNombre);
        panelDatos.add(lblCorreo);
        panelDatos.add(lblTelefono);
        panelDatos.add(lblSexo);
        panelDatos.add(lblEdad);

        JPanel panelBotones = new JPanel();
        panelBotones.setPreferredSize(new Dimension(100, 100));
        panelBotones.setLayout(new GridLayout(1, 0, 10, 10));
        panelBotones.setBackground(new Color(50, 50, 70, 200));

        lblEditar = new JLabel("<html><font color='#00FFFF'>Editar</font></html>");
        lblEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBorrar = new JLabel("<html><font color='#FF6666'>Borrar</font></html>");
        lblBorrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        panelBotones.add(lblEditar);
        panelBotones.add(lblBorrar);

        add(panelImagen, BorderLayout.WEST);
        add(panelDatos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.EAST);

        lblEditar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Editar cliente: " + nombreCompleto);
                EditarCliente editarCliente = new EditarCliente(nombreCompleto, telefono, correo, sexo, edad);
                editarCliente.setVisible(true);
                SwingUtilities.getWindowAncestor(PanelCliente.this).dispose();
            }
        });


        lblBorrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Borrar cliente: " + nombreCompleto);
                EliminarCliente eliminarCliente = new EliminarCliente(nombreCompleto, telefono, correo, sexo, edad);
                eliminarCliente.setVisible(true);
                SwingUtilities.getWindowAncestor(PanelCliente.this).dispose();
            }
        });
    }

    private ImageIcon crearImagenCircular(String sexo) {
        ImageIcon icono;
        if (sexo.equalsIgnoreCase("Hombre")) {
            icono = new ImageIcon(new ImageIcon("Imagenes/Hombre.png").getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        } else {
            icono = new ImageIcon(new ImageIcon("Imagenes/Mujer.png").getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        }
        return icono; // Imagen circular simulada
    }
}
