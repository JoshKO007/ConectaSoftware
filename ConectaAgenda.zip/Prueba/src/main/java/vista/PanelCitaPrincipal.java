package vista;

import javax.swing.*;
import java.awt.*;

public class PanelCitaPrincipal extends JPanel {

    private JLabel lblNombre;
    private JLabel lblFecha;
    private JLabel lblDetalles;
    private JLabel lblPrecio;
    private JLabel lblHora;
    private JLabel lblAnticipo;
    private JLabel lblImagenUsuario;

    public PanelCitaPrincipal(String nombreCompleto, String fecha, String detalles, String precio, String hora, String anticipo) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        setBackground(new Color(50, 50, 70, 200));
        setPreferredSize(new Dimension(600, 150));  // Ajuste del tamaño para mostrar mejor las dos líneas

        // Panel para la imagen de usuario
        JPanel panelImagen = new JPanel();
        panelImagen.setPreferredSize(new Dimension(100, 100));
        panelImagen.setLayout(new GridBagLayout());
        panelImagen.setBackground(new Color(50, 50, 70, 200));

        lblImagenUsuario = new JLabel();
        lblImagenUsuario.setPreferredSize(new Dimension(60, 60));
        lblImagenUsuario.setIcon(crearImagenCircular());
        panelImagen.add(lblImagenUsuario, new GridBagConstraints());

        // Panel para los datos del cliente
        JPanel panelDatos = new JPanel();
        panelDatos.setLayout(new GridLayout(3, 2));  // Ajuste a tres filas para acomodar dos líneas para algunos campos
        panelDatos.setBackground(new Color(50, 50, 70, 200));

        // Configura los campos en dos líneas si el texto es largo
        lblNombre = new JLabel("<html>Cliente: " + dividirEnDosLineas(nombreCompleto) + "</html>");
        lblFecha = new JLabel("Fecha: " + fecha);
        lblDetalles = new JLabel("<html>Detalles: " + dividirEnDosLineas(detalles) + "</html>");
        lblPrecio = new JLabel("Precio: $" + precio);
        lblHora = new JLabel("Hora: " + hora);
        
        // Traduce el valor de anticipo a "Sí" o "No"
        String anticipoTexto = anticipo.equals("1") ? "Sí" : "No";
        lblAnticipo = new JLabel("Anticipo: " + anticipoTexto);

        lblNombre.setForeground(Color.WHITE);
        lblFecha.setForeground(Color.WHITE);
        lblDetalles.setForeground(Color.WHITE);
        lblPrecio.setForeground(Color.WHITE);
        lblHora.setForeground(Color.WHITE);
        lblAnticipo.setForeground(Color.WHITE);

        panelDatos.add(lblNombre);
        panelDatos.add(lblFecha);
        panelDatos.add(lblDetalles);
        panelDatos.add(lblPrecio);
        panelDatos.add(lblHora);
        panelDatos.add(lblAnticipo);

        add(panelImagen, BorderLayout.WEST);
        add(panelDatos, BorderLayout.CENTER);
    }

    private ImageIcon crearImagenCircular() {
        ImageIcon icono = new ImageIcon(new ImageIcon("Imagenes/calendario.png").getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        return icono;
    }

    private String dividirEnDosLineas(String texto) {
        // Define el límite de caracteres a partir del cual el texto se dividirá en dos líneas
        int limiteCaracteres = 20;
        
        if (texto.length() > limiteCaracteres) {
            int mitad = texto.length() / 2;
            int espacio = texto.indexOf(" ", mitad);
            if (espacio != -1) {
                return texto.substring(0, espacio) + "<br>" + texto.substring(espacio + 1);
            }
        }
        return texto;  // Si el texto es corto o no hay espacio para dividir, devuélvelo sin cambios
    }
}
