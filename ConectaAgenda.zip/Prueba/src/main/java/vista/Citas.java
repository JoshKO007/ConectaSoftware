package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class Citas extends JFrame {

    private JPanel ClientesPanel;

    public Citas() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");
            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Component.arc", 999);
            UIManager.put("Button.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Conecta y Agenda");
        setSize(715, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(null);
        add(panel);

        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new FlowLayout());
        panelSuperior.setBounds(40, 20, 630, 40); 
        panelSuperior.setBackground(Color.DARK_GRAY);
        panelSuperior.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JLabel labelLista = new JLabel("Citas próximas");
        labelLista.setForeground(Color.WHITE);
        labelLista.setFont(new Font("Arial", Font.BOLD, 18));
        panelSuperior.add(labelLista);
        panel.add(panelSuperior); 

        ClientesPanel = new JPanel();
        ClientesPanel.setLayout(new GridBagLayout()); 
        ClientesPanel.setBackground(new Color(64, 64, 79, 200));
        ClientesPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JScrollPane scrollPane = new JScrollPane(ClientesPanel);
        scrollPane.setBounds(40, 60, 630, 350); 
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        panel.add(scrollPane); 

        RegistroBD dbManager = new RegistroBD();
        StringBuilder contenido = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                contenido.append(linea);
            }
        } catch (IOException o) {
            System.out.println("Error al leer el archivo de usuario: " + o.getMessage());
        }

        String user = contenido.toString(); 
        String userID = dbManager.obtenerID(user);

        List<String[]> citas = dbManager.obtenerCitasPorUsuario(userID);

        for (String[] cita : citas) {
            String cliente = cita[0];
            String fecha = cita[1];
            String detalles = cita[2];
            String precio = cita[3];
            String hora = cita[4];
            String anticipo = cita[5];

            PanelCita panelCita = new PanelCita(cliente, fecha, detalles, precio, hora, anticipo);
            ClientesPanel.setLayout(new BoxLayout(ClientesPanel, BoxLayout.Y_AXIS));
            ClientesPanel.setAlignmentY(Component.TOP_ALIGNMENT);
            panelCita.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120)); // Fijar altura para cada cita
            ClientesPanel.add(panelCita);
        }

        JButton NuevoCliente = new JButton("Nueva cita");
        NuevoCliente.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        NuevoCliente.setBounds(40, 420, 150, 30);
        panel.add(NuevoCliente);
        
        NuevoCliente.addActionListener(e -> {
            NuevaCita NCFrame = new NuevaCita();
            NCFrame.setVisible(true);
            dispose(); 
        });
        
        JButton Aceptar = new JButton("Aceptar");
        Aceptar.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Aceptar.setBounds(520, 420, 150, 30);
        panel.add(Aceptar);
        
        Aceptar.addActionListener(e -> {
            Principal PSFrame = new Principal();
            PSFrame.setVisible(true);
            dispose(); 
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Citas().setVisible(true);
        });
    }
}

