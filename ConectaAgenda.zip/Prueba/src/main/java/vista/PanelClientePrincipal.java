package vista;

import javax.swing.*;
import java.awt.*;

public class PanelClientePrincipal extends JPanel {

    private JLabel lblNombre;
    private JLabel lblImagenUsuario;

    public PanelClientePrincipal(String nombreCompleto, String sexo) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        setBackground(new Color(50, 50, 70, 100));
        setPreferredSize(new Dimension(20, 100)); 

        JPanel panelImagen = new JPanel();
        panelImagen.setPreferredSize(new Dimension(80, 100)); 
        panelImagen.setLayout(new GridBagLayout());
        panelImagen.setBackground(new Color(50, 50, 70, 200));

        lblImagenUsuario = new JLabel();
        lblImagenUsuario.setPreferredSize(new Dimension(60, 60)); 
        lblImagenUsuario.setIcon(crearImagenCircular(sexo));
        panelImagen.add(lblImagenUsuario, new GridBagConstraints());

        String[] partesNombre = nombreCompleto.split(" ", 3);
        String nombre = "Nombre: " + partesNombre[0] + " " + partesNombre[1];
        String apellido = partesNombre.length > 2 ? partesNombre[2] : "";

        lblNombre = new JLabel("<html>" + nombre + "<br>" + apellido + "</html>");
        lblNombre.setForeground(Color.WHITE);

        JPanel panelDatos = new JPanel();
        panelDatos.setLayout(new GridLayout(1, 1));
        panelDatos.setBackground(new Color(50, 50, 70, 200));
        panelDatos.add(lblNombre);

        add(panelImagen, BorderLayout.WEST);
        add(panelDatos, BorderLayout.CENTER);
    }

    private ImageIcon crearImagenCircular(String sexo) {
        ImageIcon icono;
        if (sexo.equalsIgnoreCase("Hombre")) {
            icono = new ImageIcon(new ImageIcon("Imagenes/Hombre.png").getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        } else {
            icono = new ImageIcon(new ImageIcon("Imagenes/Mujer.png").getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        }
        return icono; // Imagen circular simulada
    }
}


