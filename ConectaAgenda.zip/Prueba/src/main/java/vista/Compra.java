package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.concurrent.CountDownLatch;

public class Compra extends JFrame {

    private boolean compraExitosa; // Variable para almacenar el estado de la compra
    private WebSocketClient webSocketClient;
    private CountDownLatch latch = new CountDownLatch(1);

    public Compra() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");
            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Advertencia");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel advertencia = new JLabel("Opciones de compra");
        advertencia.putClientProperty("FlatLaf.style", "font: bold $h2.regular.font");
        advertencia.setBounds(150, 20, 350, 25);
        panel.add(advertencia);

        JLabel deteccion = new JLabel("Prueba de 30 días");
        deteccion.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        deteccion.setBounds(110, 150, 500, 25);
        panel.add(deteccion);

        JLabel peticion = new JLabel("Versión PRO");
        peticion.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        peticion.setBounds(290, 150, 500, 25);
        panel.add(peticion);

        ImageIcon iconoPrueba = new ImageIcon("/Users/josh_pc/NetBeansProjects/Prueba/imagenes/Prueba.png");
        Image imagenPruebaEscalada = iconoPrueba.getImage().getScaledInstance(82, 101, Image.SCALE_SMOOTH);
        JLabel imagenPrueba = new JLabel(new ImageIcon(imagenPruebaEscalada));
        imagenPrueba.setBounds(125, 47, 82, 101);
        panel.add(imagenPrueba);

        ImageIcon iconoPro = new ImageIcon("/Users/josh_pc/NetBeansProjects/Prueba/imagenes/Pro.png");
        Image imagenProEscalada = iconoPro.getImage().getScaledInstance(82, 101, Image.SCALE_SMOOTH);
        JLabel imagenPro = new JLabel(new ImageIcon(imagenProEscalada));
        imagenPro.setBounds(287, 47, 82, 101);
        panel.add(imagenPro);

        JButton probar = new JButton("Probar");
        probar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        probar.setBounds(118, 185, 95, 25);
        panel.add(probar);
        
        probar.addActionListener(e -> {
            StringBuilder contenido = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                    String linea;
                    while ((linea = reader.readLine()) != null) {
                        contenido.append(linea);
                    }
                } catch (IOException o) {
            }
                
            String user = contenido.toString(); 
            RegistroBD dbManager = new RegistroBD();
            String userID = dbManager.obtenerID(user); 
            boolean usuarioVerificacion = dbManager.registrarPrueba(user);
            if(usuarioVerificacion){
            System.out.println("Licencia actualizada: Prueba de 30 dias");
            JOptionPane.showMessageDialog(null, "Haz iniciado tu prueba de 30 días", "Pueba gratuida", JOptionPane.WARNING_MESSAGE);
            boolean esta = dbManager.usuarioEnNegocios(userID);
            if(esta){
                Usuario newFrame = new Usuario();
                newFrame.setVisible(true);
                this.dispose();
            }else{
                ConfiguracionNegocio newFrame = new ConfiguracionNegocio();
                newFrame.setVisible(true);
                this.dispose();
            }
            }  
        });

        JButton comprar = new JButton("Comprar");
        comprar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        comprar.setBounds(281, 185, 95, 25);
        panel.add(comprar);

        comprar.addActionListener(e -> {
            try {
                String urlCompra = "http://localhost:3001";  

                // Abre el navegador
                Desktop desktop = Desktop.getDesktop();
                if (desktop.isSupported(Desktop.Action.BROWSE)) {
                    desktop.browse(new java.net.URI(urlCompra));
                }

                // Muestra la barra de progreso
                JFrame progressFrame = new JFrame("Verificando compra");
                JProgressBar progressBar = new JProgressBar();
                progressBar.setIndeterminate(true);
                progressBar.setString("Verificando...");
                progressBar.setStringPainted(true);
                progressBar.setForeground(new Color(255, 112, 153)); // Color del progreso (ej. azul claro)
                progressBar.setBackground(new Color(191, 191, 191)); // Color de fondo de la barra

                // Personaliza el borde y la forma de la barra
                progressBar.setBorder(BorderFactory.createLineBorder(new Color(191, 191, 191), 2));
                progressBar.setUI(new javax.swing.plaf.basic.BasicProgressBarUI() {
                    @Override
                    public void paint(Graphics g, JComponent c) {
                        g.setColor(progressBar.getBackground());
                        g.fillRect(0, 0, progressBar.getWidth(), progressBar.getHeight());
                        super.paint(g, c);
                    }
                });

                progressFrame.add(progressBar);
                progressFrame.setSize(300, 100);
                progressFrame.setLocationRelativeTo(null);
                progressFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                progressFrame.setVisible(true);

                // Inicia la conexión WebSocket para verificar la compra
                iniciarWebSocket(progressFrame);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        JButton regresar = new JButton("Regresar");
        regresar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        regresar.setBounds(198, 230, 95, 25);
        panel.add(regresar);

        regresar.addActionListener(e -> {
            Inicio inicioFrame = new Inicio();
            inicioFrame.setVisible(true);
            dispose();
        });
    }

    public void iniciarWebSocket(JFrame progressFrame) {
        try {
            URI uri = new URI("ws://localhost:3001");
            Compra currentFrame = this;

            webSocketClient = new WebSocketClient(uri) {
                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    System.out.println("Conectado al servidor WebSocket");
                }

                @Override
                public void onMessage(String message) {
                    System.out.println("Mensaje recibido del servidor: " + message);
                    if (message.contains("success")) {
                        compraExitosa = true; // Marca la compra como exitosa
                        progressFrame.dispose(); // Cierra la ventana de progreso
                        JOptionPane.showMessageDialog(null, "¡Compra exitosa!"); // Muestra el mensaje de éxito
                        latch.countDown(); // Notifica que la compra fue exitosa

                        StringBuilder contenido = new StringBuilder();
                        try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                            String linea;
                            while ((linea = reader.readLine()) != null) {
                                contenido.append(linea);
                            }
                        } catch (IOException o) {
                        }

                        String user = contenido.toString(); 
                        RegistroBD dbManager = new RegistroBD();
                        String userID = dbManager.obtenerID(user); 
                        boolean usuarioVerificacion = dbManager.registrarPro(user);
                        if(usuarioVerificacion){
                            System.out.println("Licencia actualizada: Prueba de 30 dias");
                            JOptionPane.showMessageDialog(null, "Haz iniciado tu licencia completa, Felicidades.", "Versión Pro", JOptionPane.WARNING_MESSAGE);
                            boolean esta = dbManager.usuarioEnNegocios(userID);
                            if(esta){
                                Usuario newFrame = new Usuario();
                                newFrame.setVisible(true);
                                currentFrame.dispose(); // Usamos currentFrame.dispose()
                            } else {
                                ConfiguracionNegocio newFrame = new ConfiguracionNegocio();
                                newFrame.setVisible(true);
                                currentFrame.dispose(); // Usamos currentFrame.dispose()
                            }
                        }
                    } else if (message.contains("cancel")) {
                        compraExitosa = false; 
                        JOptionPane.showMessageDialog(null, "Compra cancelada."); 
                        latch.countDown(); 
                    }
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    System.out.println("Conexión cerrada: " + reason);
                }

                @Override
                public void onError(Exception ex) {
                    System.out.println("Ocurrió un error: " + ex.getMessage());
                }
            };
            webSocketClient.connect();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public static void main(String[] args) {
        System.setProperty("apple.awt.application.appearance", "system");
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");

        SwingUtilities.invokeLater(() -> {
            new Compra().setVisible(true);
        });
    }
}
