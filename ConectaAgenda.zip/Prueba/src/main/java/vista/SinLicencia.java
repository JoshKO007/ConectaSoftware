package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SinLicencia extends JFrame {

    private JTextField usuarioUS;
    private JPasswordField contraseñaUS;

    public SinLicencia() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Advertencia");
        setSize(500, 270);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel advertencia = new JLabel("¡No has comprado este producto!");
        advertencia.putClientProperty("FlatLaf.style", "font: bold $h2.regular.font");
        advertencia.setBounds(95, 50, 350, 25);
        panel.add(advertencia);
        
        JLabel deteccion = new JLabel("Hemos detectado que no posees una licencia para usar este programa.");
        deteccion.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        deteccion.setBounds(29, 95, 500, 25);
        panel.add(deteccion);
        
        JLabel peticion = new JLabel("Puedes comprar el producto o probarlo por 30 días.");
        peticion.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        peticion.setBounds(86, 115, 500, 25);
        panel.add(peticion);
        
        JButton comprar = new JButton("Opciones de compra");
        comprar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        comprar.setBounds(95, 160, 170, 25);
        panel.add(comprar);

        comprar.addActionListener(e -> {
            Compra inicioFrame = new Compra();
            inicioFrame.setVisible(true);
            dispose();
        });        
        
        
        JButton regresar = new JButton("Regresar");
        regresar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        regresar.setBounds(287, 160, 100, 25);
        panel.add(regresar);
        
        regresar.addActionListener(e -> {
            Inicio inicioFrame = new Inicio();
            inicioFrame.setVisible(true);
            dispose();
        });
    }

    
    public static void main(String[] args) {
        System.setProperty( "apple.awt.application.appearance", "system" );
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");

        SwingUtilities.invokeLater(() -> {
            new SinLicencia().setVisible(true);
        });
    }
}

