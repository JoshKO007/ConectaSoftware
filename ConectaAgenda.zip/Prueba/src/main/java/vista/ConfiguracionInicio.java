package vista;

import Modelo.RegistroBD;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConfiguracionInicio extends JFrame {

    private JTextField usuarioUS;
    private JPasswordField contraseñaUS;

    public ConfiguracionInicio() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Configuración");
        setSize(300, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel usuario = new JLabel("Configuración");
        usuario.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        usuario.setBounds(92, 30, 150, 25);
        panel.add(usuario);
        
        JLabel contra = new JLabel("Cambiar contraseñas");
        contra.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        contra.setBounds(65, 60, 190, 25);
        panel.add(contra);
        
        JButton Admin = new JButton("Administrador");
        Admin.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        Admin.setBounds(73, 100, 150, 25);
        panel.add(Admin);

        Admin.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String input = JOptionPane.showInputDialog(null, "Ingresa la contraseña actual para modificarla:", "Contraseña", JOptionPane.PLAIN_MESSAGE);      
            RegistroBD dbManager = new RegistroBD();
            StringBuilder contenido = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    contenido.append(linea);
                }
            } catch (IOException o) {
                System.out.println("Error al leer usuario.txt: " + o.getMessage());
            }

            String user = contenido.toString(); 
            String userID = dbManager.obtenerID(user);
            String contraseña = dbManager.contraAdmin(userID);

            while (!input.equals(contraseña)) {
                input = JOptionPane.showInputDialog(null, "Contraseña incorrecta, ingresa la contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            }

            String newinput = JOptionPane.showInputDialog(null, "Contraseña correcta, ingresa la nueva contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            boolean cambio = dbManager.UpdatecontraAdmin(userID, newinput);
            if(cambio){
                JOptionPane.showMessageDialog(null, "Contraseña actualizada correctamente, vuelve a iniciar sesión", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                Usuario USFrame = new Usuario();
                USFrame.setVisible(true);
                dispose();
            }
        }
        });
   
        JButton US1 = new JButton("Usuario 1");
        US1.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        US1.setBounds(73, 130, 150, 25);
        panel.add(US1);
        
        US1.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String input = JOptionPane.showInputDialog(null, "Ingresa la contraseña actual para modificarla:", "Contraseña", JOptionPane.PLAIN_MESSAGE);      
            RegistroBD dbManager = new RegistroBD();
            StringBuilder contenido = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    contenido.append(linea);
                }
            } catch (IOException o) {
                System.out.println("Error al leer usuario.txt: " + o.getMessage());
            }

            String user = contenido.toString(); 
            String userID = dbManager.obtenerID(user);
            String contraseña = dbManager.contraUS1(userID);

            while (!input.equals(contraseña)) {
                input = JOptionPane.showInputDialog(null, "Contraseña incorrecta, ingresa la contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            }

            String newinput = JOptionPane.showInputDialog(null, "Contraseña correcta, ingresa la nueva contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            boolean cambio = dbManager.UpdatecontraUS1(userID, newinput);
            if(cambio){
                JOptionPane.showMessageDialog(null, "Contraseña actualizada correctamente, vuelve a iniciar sesión", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                Usuario USFrame = new Usuario();
                USFrame.setVisible(true);
                dispose();
            }
        }
        });
        
        JButton US2 = new JButton("Usuario 2");
        US2.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        US2.setBounds(73, 160, 150, 25);
        panel.add(US2);
        
        US2.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String input = JOptionPane.showInputDialog(null, "Ingresa la contraseña actual para modificarla:", "Contraseña", JOptionPane.PLAIN_MESSAGE);      
            RegistroBD dbManager = new RegistroBD();
            StringBuilder contenido = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    contenido.append(linea);
                }
            } catch (IOException o) {
                System.out.println("Error al leer usuario.txt: " + o.getMessage());
            }

            String user = contenido.toString(); 
            String userID = dbManager.obtenerID(user);
            String contraseña = dbManager.contraUS2(userID);

            while (!input.equals(contraseña)) {
                input = JOptionPane.showInputDialog(null, "Contraseña incorrecta, ingresa la contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            }

            String newinput = JOptionPane.showInputDialog(null, "Contraseña correcta, ingresa la nueva contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            boolean cambio = dbManager.UpdatecontraUS2(userID, newinput);
            if(cambio){
                JOptionPane.showMessageDialog(null, "Contraseña actualizada correctamente, vuelve a iniciar sesión", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                Usuario USFrame = new Usuario();
                USFrame.setVisible(true);
                dispose();
            }
        }
        });
        
        JButton US3 = new JButton("Usuario 3");
        US3.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        US3.setBounds(73, 190, 150, 25);
        panel.add(US3);

        US3.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            String input = JOptionPane.showInputDialog(null, "Ingresa la contraseña actual para modificarla:", "Contraseña", JOptionPane.PLAIN_MESSAGE);      
            RegistroBD dbManager = new RegistroBD();
            StringBuilder contenido = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(new FileReader("usuario.txt"))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    contenido.append(linea);
                }
            } catch (IOException o) {
                System.out.println("Error al leer usuario.txt: " + o.getMessage());
            }

            String user = contenido.toString(); 
            String userID = dbManager.obtenerID(user);
            String contraseña = dbManager.contraUS3(userID);

            while (!input.equals(contraseña)) {
                input = JOptionPane.showInputDialog(null, "Contraseña incorrecta, ingresa la contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            }

            String newinput = JOptionPane.showInputDialog(null, "Contraseña correcta, ingresa la nueva contraseña:", "Contraseña", JOptionPane.PLAIN_MESSAGE);
            boolean cambio = dbManager.UpdatecontraUS3(userID, newinput);
            if(cambio){
                JOptionPane.showMessageDialog(null, "Contraseña actualizada correctamente, vuelve a iniciar sesión", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                Usuario USFrame = new Usuario();
                USFrame.setVisible(true);
                dispose();
            }
        }
        });
        
        JButton aceptar = new JButton("Aceptar");
        aceptar.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        aceptar.setBounds(97, 280, 100, 25);
        panel.add(aceptar);
        
        aceptar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            Principal PRFrame = new Principal();
            PRFrame.setVisible(true);
            dispose();
        }
        });
                
    }
    
    public static void main(String[] args) {
        System.setProperty( "apple.awt.application.appearance", "system" );
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");

        SwingUtilities.invokeLater(() -> {
            new ConfiguracionInicio().setVisible(true);
        });
    }
}

