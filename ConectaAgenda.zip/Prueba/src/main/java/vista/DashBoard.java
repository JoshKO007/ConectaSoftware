package vista;

import java.awt.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class DashBoard extends JFrame {

    public DashBoard() {
        setTitle("Dashboard - Análisis de Clientes y Citas");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un panel principal con GridBagLayout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 10, 10, 10); // Márgenes entre los gráficos
        gbc.weightx = 1;
        gbc.weighty = 1;

        // Crear las tres gráficas
        ChartPanel pieChart = createPieChart();
        ChartPanel barChart = createBarChart();
        ChartPanel dispersionChart = createDispersionChart();

        // Agregar las gráficas al panel principal
        // Gráfico de pastel (arriba izquierda)
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(pieChart, gbc);

        // Gráfico de barras (arriba derecha)
        gbc.gridx = 1;
        gbc.gridy = 0;
        mainPanel.add(barChart, gbc);

        // Gráfico de dispersión (centrado en la segunda fila)
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2; // Ocupa dos columnas
        mainPanel.add(dispersionChart, gbc);

        // Crear un panel para el botón
        JPanel buttonPanel = new JPanel();
        JButton acceptButton = new JButton("Aceptar");
        acceptButton.addActionListener(e -> {
            // Redirigir a la clase Principal
            Principal principal = new Principal(); // Cambiar "Principal" por el nombre correcto de tu clase
            principal.setVisible(true);
            this.dispose(); // Cierra la ventana actual
        });
        buttonPanel.add(acceptButton);

        // Crear un panel de contenedor y agregar los paneles
        JPanel container = new JPanel(new BorderLayout());
        container.add(mainPanel, BorderLayout.CENTER);
        container.add(buttonPanel, BorderLayout.SOUTH);

        // Configurar el contenido de la ventana
        setContentPane(container);
    }

    private ChartPanel createPieChart() {
        DefaultPieDataset dataset = new DefaultPieDataset();
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/servicios",
                    "root",
                    "tartara21"
            );

            String query = "SELECT Sexo, COUNT(*) AS Total FROM clientes GROUP BY Sexo";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String sexo = rs.getString("Sexo");
                int total = rs.getInt("Total");
                dataset.setValue(sexo, total);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JFreeChart chart = ChartFactory.createPieChart(
                "Distribución por Sexo",
                dataset,
                true,
                true,
                false
        );

        return new ChartPanel(chart);
    }

    private ChartPanel createBarChart() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/servicios",
                    "root",
                    "tartara21"
            );

            String query = "SELECT " +
                    "CASE " +
                    "WHEN edad BETWEEN 0 AND 18 THEN '0-18' " +
                    "WHEN edad BETWEEN 19 AND 35 THEN '19-35' " +
                    "WHEN edad BETWEEN 36 AND 60 THEN '36-60' " +
                    "ELSE '61+' END AS RangoEdad, " +
                    "COUNT(*) AS Total " +
                    "FROM clientes " +
                    "GROUP BY RangoEdad";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String rangoEdad = rs.getString("RangoEdad");
                int total = rs.getInt("Total");
                dataset.addValue(total, "Clientes", rangoEdad);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JFreeChart chart = ChartFactory.createBarChart(
                "Clientes por Rango de Edad",
                "Rango de Edad",
                "Cantidad de Clientes",
                dataset
        );

        return new ChartPanel(chart);
    }

    private ChartPanel createDispersionChart() {
        TimeSeries series = new TimeSeries("Precios de Citas");
        try {
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/servicios",
                    "root",
                    "tartara21"
            );

            String query = "SELECT Fecha_cita, Precio_cita FROM citas ORDER BY Fecha_cita";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

            while (rs.next()) {
                String fechaStr = rs.getString("Fecha_cita");
                Date fecha = dateFormat.parse(fechaStr);
                double precio = rs.getDouble("Precio_cita");
                series.add(new Day(fecha), precio);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        TimeSeriesCollection dataset = new TimeSeriesCollection();
        dataset.addSeries(series);

        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Precios de Citas por Fecha",
                "Fecha",
                "Precio",
                dataset,
                true,
                true,
                false
        );

        return new ChartPanel(chart);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DashBoard dashboard = new DashBoard();
            dashboard.setVisible(true);
        });
    }
}
