package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PanelCita extends JPanel {

    private JLabel lblCliente;
    private JLabel lblFecha;
    private JLabel lblDetalles;
    private JLabel lblPrecio;
    private JLabel lblHora;
    private JLabel lblAnticipo;
    private JLabel lblEditar;
    private JLabel lblBorrar;
    private JLabel lblImagenUsuario;

    public PanelCita(String cliente, String fecha, String detalles, String precio, String hora, String anticipo) {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        setBackground(new Color(50, 50, 70, 200));
        
        setPreferredSize(new Dimension(600, 100)); // Ajusta el valor de la altura según lo que necesites (100 es un ejemplo)
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 100)); // Asegura que el panel se expanda horizontalmente y mantenga la altura
        setAlignmentX(Component.LEFT_ALIGNMENT); // Alineación a la izquierda para ocupar todo el ancho

        JPanel panelImagen = new JPanel();
        panelImagen.setPreferredSize(new Dimension(100, 100));
        panelImagen.setLayout(new GridBagLayout());
        panelImagen.setBackground(new Color(50, 50, 70, 200));

        lblImagenUsuario = new JLabel();
        lblImagenUsuario.setPreferredSize(new Dimension(70, 70));  // Tamaño mayor para la imagen
        lblImagenUsuario.setIcon(crearImagenCircular());
        panelImagen.add(lblImagenUsuario, new GridBagConstraints());

        lblCliente = new JLabel("Cliente: " + cliente);
        lblCliente.setForeground(Color.WHITE);
        lblFecha = new JLabel("Fecha: " + fecha);
        lblFecha.setForeground(Color.WHITE);
        lblDetalles = new JLabel("Detalles: " + detalles);
        lblDetalles.setForeground(Color.WHITE);
        lblPrecio = new JLabel("Precio: $" + precio);
        lblPrecio.setForeground(Color.WHITE);
        lblHora = new JLabel("Hora: " + hora);
        lblHora.setForeground(Color.WHITE);
        lblAnticipo = new JLabel("Anticipo: " + anticipo);
        lblAnticipo.setForeground(Color.WHITE);

        JPanel panelDatos = new JPanel(new GridLayout(3, 2, 5, 5));
        panelDatos.setBackground(new Color(50, 50, 70, 200));
        panelDatos.add(lblCliente);
        panelDatos.add(lblFecha);
        panelDatos.add(lblDetalles);
        panelDatos.add(lblPrecio);
        panelDatos.add(lblHora);
        panelDatos.add(lblAnticipo);

        JPanel panelBotones = new JPanel(new GridLayout(2, 1));
        panelBotones.setPreferredSize(new Dimension(70, 40));
        panelBotones.setBackground(new Color(50, 50, 70, 200));

        lblEditar = new JLabel("<html><font color='#00FFFF'>Confirmar</font></html>");
        lblEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBorrar = new JLabel("<html><font color='#FF6666'>Cancelar</font></html>");
        lblBorrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        panelBotones.add(lblEditar);
        panelBotones.add(lblBorrar);

        add(panelImagen, BorderLayout.WEST);
        add(panelDatos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.EAST);

        lblEditar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Confirmar cita: " + cliente);
            }
        });

        lblBorrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Cancelar cita: " + cliente);
            }
        });
    }

    private ImageIcon crearImagenCircular() {
        ImageIcon icono = new ImageIcon(new ImageIcon("Imagenes/calendario.png").getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH));
        return icono;
    }
}
