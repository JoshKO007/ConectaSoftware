package vista;

import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import org.json.JSONObject;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class PrincipalNoRoot extends JFrame {

    private JLabel horaLabel;
    private JLabel climaLabel;
    private JPanel climaPanel;
    private JPanel citasPanel;
    private JLabel imagenClimaLabel;
    private static final String API_URL = "https://api.open-meteo.com/v1/forecast?latitude=19.4326&longitude=-99.1332&current_weather=true"; 

    private double temperaturaActual = 0;
    private String condicionClimatica = "";

    public PrincipalNoRoot() {
        configurarEstilos();
        inicializarComponentes();
        actualizarHora();
        actualizarClima();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");
            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Conecta y Agenda");
        setSize(1000, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel(null);
        add(panel);

        JPanel bienvenidaPanel = new JPanel();
        bienvenidaPanel.setBounds(40, 100, 500, 100);
        bienvenidaPanel.setBackground(new Color(64, 64, 79, 200));
        bienvenidaPanel.setLayout(new BorderLayout());
        bienvenidaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JLabel mensajeBienvenida = new JLabel("¡Bienvenido a Conecta y Agenda!", SwingConstants.CENTER);
        mensajeBienvenida.setForeground(Color.WHITE);
        mensajeBienvenida.setFont(new Font("Arial", Font.BOLD, 24));
        bienvenidaPanel.add(mensajeBienvenida, BorderLayout.CENTER);

        panel.add(bienvenidaPanel);

        climaPanel = new JPanel();
        climaPanel.setBounds(560, 100, 400, 100);
        climaPanel.setLayout(null);
        climaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        
        panel.add(climaPanel);

        horaLabel = new JLabel("Hora: --:--:--");
        horaLabel.setForeground(Color.WHITE);
        horaLabel.setFont(new Font("Arial", Font.BOLD, 24));
        horaLabel.setBounds(30, 10, 200, 40);
        climaPanel.add(horaLabel);

        climaLabel = new JLabel("Clima: -- °C");
        climaLabel.setForeground(Color.WHITE);
        climaLabel.setFont(new Font("Arial", Font.BOLD, 24));
        climaLabel.setBounds(30, 50, 200, 40);
        climaPanel.add(climaLabel);

        imagenClimaLabel = new JLabel();
        imagenClimaLabel.setBounds(260, 10, 100, 80);
        climaPanel.add(imagenClimaLabel);

        citasPanel = new JPanel();
        citasPanel.setBounds(40, 250, 630, 480);
        citasPanel.setLayout(new BorderLayout());
        citasPanel.setBackground(new Color(64, 64, 79, 200));
        citasPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        panel.add(citasPanel);

        JPanel panelSuperior = new JPanel();
        panelSuperior.setLayout(new FlowLayout());
        panelSuperior.setBackground(Color.DARK_GRAY);
        panelSuperior.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        citasPanel.add(panelSuperior, BorderLayout.NORTH);

        JLabel labelProxima = new JLabel("Citas próximas");
        labelProxima.setForeground(Color.WHITE);
        labelProxima.setFont(new Font("Arial", Font.BOLD, 18));
        panelSuperior.add(labelProxima);
        
        JPanel clientesPanel = new JPanel();
        clientesPanel.setBounds(700, 250, 260, 270);
        clientesPanel.setLayout(new BorderLayout());
        clientesPanel.setBackground(new Color(64, 64, 79, 200));
        clientesPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        panel.add(clientesPanel);

        JPanel panelClientesSuperior = new JPanel();
        panelClientesSuperior.setLayout(new FlowLayout());
        panelClientesSuperior.setPreferredSize(new Dimension(260, 37));
        panelClientesSuperior.setBackground(Color.DARK_GRAY);
        panelClientesSuperior.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        clientesPanel.add(panelClientesSuperior, BorderLayout.NORTH);

        JLabel labelClientes = new JLabel("Clientes");
        labelClientes.setForeground(Color.WHITE);
        labelClientes.setFont(new Font("Arial", Font.BOLD, 18));
        panelClientesSuperior.add(labelClientes);
        
        JButton CambiarUS = new JButton("<html><div style='text-align: center;'>Cambiar<br>usuario</div></html>");
        CambiarUS.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        CambiarUS.setBounds(260, 5, 200, 70);
        CambiarUS.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(CambiarUS);

        JButton Clientes = new JButton("<html><div style='text-align: center;'>Lista<br>de clientes</div></html>");
        Clientes.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Clientes.setBounds(460, 5, 200, 70);
        Clientes.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(Clientes);

        JButton Perfil = new JButton();
        Perfil.setBounds(660, 5, 80, 70);
        ImageIcon originalIcon = new ImageIcon("imagenes/Usuario.png");
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        Perfil.setIcon(resizedIcon);
        Perfil.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        panel.add(Perfil);
        
        JButton consuCitas = new JButton("Ver todas las citas");
        consuCitas.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        consuCitas.setBounds(700, 530, 260, 60);
        consuCitas.putClientProperty( "JButton.buttonType", "roundRect" );
        panel.add(consuCitas);
        
        JButton GesHor = new JButton("Gestionar horarios");
        GesHor.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        GesHor.setBounds(700, 600, 260, 60);
        GesHor.putClientProperty( "JButton.buttonType", "roundRect" );
        panel.add(GesHor);
        
        JButton Nueva = new JButton("Nueva Cita");
        Nueva.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Nueva.setBounds(700, 670, 260, 60);
        Nueva.putClientProperty( "JButton.buttonType", "roundRect" );
        panel.add(Nueva);        
        
        JLabel Licencia = new JLabel("Licencia: ");
        Licencia.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Licencia.setBounds(40, 720, 260, 60);
        panel.add(Licencia);  
    }

    private void actualizarHora() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                Date now = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                horaLabel.setText("Hora: " + sdf.format(now));

                int hora = now.getHours();
                Color colorFondo;

                if (hora >= 0 && hora < 5) {
                    colorFondo = new Color(10, 10, 20);
                } else if (hora >= 5 && hora < 12) {
                    colorFondo = new Color(75, 0, 130);
                } else if (hora >= 12 && hora < 17) {
                    colorFondo = new Color(135, 206, 235);
                } else {
                    colorFondo = new Color(0, 0, 139);
                }

                if (temperaturaActual <= 0) {
                    colorFondo = colorFondo.brighter();
                } else if (temperaturaActual >= 30) {
                    colorFondo = colorFondo.darker();
                }

                climaPanel.setBackground(colorFondo);
                actualizarImagenClima();
            }
        }, 0, 1000);
    }

    private void actualizarClima() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                try {
                    URL url = new URL(API_URL);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");

                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();

                    JSONObject json = new JSONObject(response.toString());
                    JSONObject currentWeather = json.getJSONObject("current_weather");
                    temperaturaActual = currentWeather.getDouble("temperature");
                    int weatherCode = currentWeather.getInt("weathercode");

                    String[] weatherDescriptions = {"Clear sky", "Mainly clear", "Partly cloudy", "Overcast", "Fog", "Drizzle", "Rain", "Snow", "Thunderstorm"};

                    if (weatherCode >= 0 && weatherCode < weatherDescriptions.length) {
                        condicionClimatica = weatherDescriptions[weatherCode];
                    } else {
                        condicionClimatica = "Clima desconocido"; 
                    }


                    climaLabel.setText(String.format("Clima: %.1f °C", temperaturaActual));

                } catch (Exception e) {
                    climaLabel.setText("Clima: Error");
                    e.printStackTrace();
                }
            }
        }, 0, 1800000);
    }

    private void actualizarImagenClima() {
        String imagenPath;
        if (condicionClimatica.toLowerCase().contains("nublado")) {
            int hora = Integer.parseInt(horaLabel.getText().substring(6, 8));
            if (hora >= 6 && hora < 18) {
                imagenPath = "imagenes/SolNube.png";
            } else {
                imagenPath = "imagenes/LunaNube.png";
            }
        } else if (condicionClimatica.toLowerCase().contains("lluvia")) {
            imagenPath = "imagenes/Nube.png";
        } else {
            int hora = Integer.parseInt(horaLabel.getText().substring(6, 8));
            if (hora >= 6 && hora < 18) {
                imagenPath = "imagenes/Sol.png";
            } else {
                imagenPath = "imagenes/Luna.png";
            }
        }

        ImageIcon imagenClimaIcon = new ImageIcon(imagenPath);
        Image imagenClima = imagenClimaIcon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        imagenClimaLabel.setIcon(new ImageIcon(imagenClima));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PrincipalNoRoot().setVisible(true));
    }
}
