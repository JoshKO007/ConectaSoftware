package vista;

import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import Modelo.RegistroBD;

public class Registro extends JFrame {

    private JTextField correoUS;
    private JTextField usuarioUS;
    private JPasswordField contraseñaUS;
    private JPasswordField VerContraseñaUS;

    public Registro() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Registro");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel instruccion = new JLabel("Completa los campos para crear tu cuenta:");
        instruccion.putClientProperty("FlatLaf.style", "font: bold $h2.regular.font");
        instruccion.setBounds(50, 15, 500, 25);
        panel.add(instruccion);

        JLabel correo = new JLabel("Correo Electrónico:");
        correo.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        correo.setBounds(76, 70, 150, 25);
        panel.add(correo);

        correoUS = new JTextField();
        correoUS.putClientProperty("FlatLaf.style", "font: $h4.font");
        correoUS.setHorizontalAlignment(JTextField.CENTER);
        correoUS.setBounds(228, 70, 200, 25);
        panel.add(correoUS);

        JLabel usuario = new JLabel("Nombre de usuario:");
        usuario.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        usuario.setBounds(76, 110, 150, 25);
        panel.add(usuario);

        usuarioUS = new JTextField();
        usuarioUS.putClientProperty("FlatLaf.style", "font: $h4.font");
        usuarioUS.setHorizontalAlignment(JTextField.CENTER);
        usuarioUS.setBounds(228, 110, 200, 25);
        panel.add(usuarioUS);

        JLabel contraseña = new JLabel("Contraseña:");
        contraseña.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        contraseña.setBounds(131, 150, 150, 25);
        panel.add(contraseña);

        contraseñaUS = new JPasswordField();
        contraseñaUS.putClientProperty("FlatLaf.style", "font: $h4.font");
        contraseñaUS.setHorizontalAlignment(JTextField.CENTER);
        contraseñaUS.setBounds(228, 150, 200, 25);
        panel.add(contraseñaUS);

        JLabel ojitoLabel1 = crearBotonOjito(contraseñaUS);
        ojitoLabel1.setBounds(430, 150, 30, 25);
        panel.add(ojitoLabel1);

        JLabel verContraseña = new JLabel("Verifica Contraseña:");
        verContraseña.putClientProperty("FlatLaf.style", "font: bold $h3.regular.font");
        verContraseña.setBounds(72, 190, 200, 25);
        panel.add(verContraseña);

        VerContraseñaUS = new JPasswordField();
        VerContraseñaUS.putClientProperty("FlatLaf.style", "font: $h4.font");
        VerContraseñaUS.setHorizontalAlignment(JTextField.CENTER);
        VerContraseñaUS.setBounds(228, 190, 200, 25);
        panel.add(VerContraseñaUS);

        JLabel ojitoLabel2 = crearBotonOjito(VerContraseñaUS);
        ojitoLabel2.setBounds(430, 190, 30, 25);
        panel.add(ojitoLabel2);

        JButton aceptar = new JButton("Registrarse");
        aceptar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        aceptar.setBounds(175, 250, 150, 30);
        panel.add(aceptar);

        JLabel tienes = new JLabel("¿Ya tienes una cuenta?");
        tienes.putClientProperty("FlatLaf.style", "font: $h4.font");
        tienes.setBounds(180, 290, 155, 30);
        panel.add(tienes);

        JButton iniciar = new JButton("Iniciar Sesión");
        iniciar.setBounds(175, 320, 150, 30);
        iniciar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        panel.add(iniciar);

        iniciar.addActionListener(e -> {
            Inicio inicioFrame = new Inicio();
            inicioFrame.setVisible(true);
            dispose();
        });

        aceptar.addActionListener(e -> registrarUsuario());
    }

    private JLabel crearBotonOjito(JPasswordField campoContraseña) {
        JLabel ojitoLabel = new JLabel("🔒");
        ojitoLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        ojitoLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        ojitoLabel.addMouseListener(new MouseAdapter() {
            private boolean passwordVisible = false;

            @Override
            public void mouseClicked(MouseEvent e) {
                passwordVisible = !passwordVisible;
                if (passwordVisible) {
                    campoContraseña.setEchoChar((char) 0);
                    ojitoLabel.setText("🔓"); 
                } else {
                    campoContraseña.setEchoChar('*');
                    ojitoLabel.setText("🔒");
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                ojitoLabel.setForeground(Color.YELLOW); 
            }

            @Override
            public void mouseExited(MouseEvent e) {
                ojitoLabel.setForeground(Color.WHITE); 
            }
        });
        return ojitoLabel;
    }

    private void registrarUsuario() {
        String correo = correoUS.getText().trim();
        String usuario = usuarioUS.getText().trim();
        String contraseña = new String(contraseñaUS.getPassword()).trim();
        String verContraseña = new String(VerContraseñaUS.getPassword()).trim();

        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        Pattern emailPattern = Pattern.compile(emailRegex);
        Matcher emailMatcher = emailPattern.matcher(correo);

        if (correo.isEmpty() || !emailMatcher.matches()) {
            JOptionPane.showMessageDialog(this, "Por favor, introduce un correo electrónico válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (usuario.isEmpty() || !usuario.matches("[a-zA-Z0-9_]+")) {
            JOptionPane.showMessageDialog(this, "El nombre de usuario no debe contener caracteres especiales.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (contraseña.isEmpty() || !contraseña.equals(verContraseña)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden o están vacías.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        RegistroBD dbManager = new RegistroBD();
        boolean exito = dbManager.insertarUsuario(usuario, correo, contraseña);

        if (exito) {
            String userID = dbManager.obtenerID(usuario); 
            dbManager.closeConnection(); 

            dbManager = new RegistroBD();
            boolean licencia = dbManager.insertarLicencia(userID);
            dbManager.closeConnection();

            if (licencia) {
                System.out.println("Licencia agregada");
            } else {
                System.out.println("Error al agregar licencia");
            }

            JOptionPane.showMessageDialog(this, "Registro exitoso.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            dbManager = new RegistroBD();
            boolean sesiones = dbManager.insertarSesiones(userID);
            dbManager.closeConnection();
            
            if (sesiones){
                System.out.println("Contraseñas agregadas con exito");
            } else {
                System.out.println("Error al agragar las contraseñas");
            }
            Inicio inicioFrame = new Inicio();
            inicioFrame.setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "El usuario o correo eléctronico ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
