package vista;

import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class PantallaCarga extends JFrame {

    private JProgressBar progressBar;
    private JLabel mensajeLabel;

    public PantallaCarga() {
        configurarEstilos();
        inicializarComponentes();
        verificarConexion();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Verificando conexión...");
        setSize(300, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        add(panel);

        mensajeLabel = new JLabel("Verificando conexión...", SwingConstants.CENTER);
        mensajeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(mensajeLabel, BorderLayout.CENTER);

        progressBar = new JProgressBar(0, 100);
        progressBar.setValue(0);
        progressBar.setStringPainted(true);
        panel.add(progressBar, BorderLayout.SOUTH);
    }

    private void verificarConexion() {
        new Thread(() -> {
            try {
                for (int i = 0; i <= 100; i += 20) {
                    progressBar.setValue(i);
                    Thread.sleep(500); 
                }

                if (internet()) {
                    mensajeLabel.setText("Conexión exitosa.");
                    Thread.sleep(1000); 
                    SwingUtilities.invokeLater(() -> {
                        new Inicio().setVisible(true); 
                        dispose();
                    });
                } else {
                    mensajeLabel.setText("No hay conexión a internet.");
                    JOptionPane.showMessageDialog(this, "No se ha detectado conexión a internet. La aplicación se cerrará.", "Error", JOptionPane.ERROR_MESSAGE);
                    System.exit(0); 
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static boolean internet() {
        try {
            URL url = new URL("http://www.google.com");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(5000); 
            connection.connect();

            int responseCode = connection.getResponseCode();
            return (responseCode >= 200 && responseCode < 400); 
        } catch (Exception e) {
            return false;
        }
    }

    public static void main(String[] args) {
        System.setProperty( "apple.awt.application.appearance", "system" );
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");
        
        SwingUtilities.invokeLater(() -> {
            new PantallaCarga().setVisible(true); 
        });
    }
}
