package vista;

import Modelo.RegistroBD;
import Vista.*;
import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Default extends JFrame {

    private JTextField usuarioUS;
    private JPasswordField contraseñaUS;

    public Default() {
        configurarEstilos();
        inicializarComponentes();
    }

    private void configurarEstilos() {
        try {
            System.setProperty("apple.awt.application.name", "Conecta y Agenda");
            System.setProperty("apple.awt.application.appearance", "system");

            UIManager.setLookAndFeel(new FlatDarkPurpleIJTheme());
            UIManager.put("Button.arc", 999);
            UIManager.put("Component.arc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("TextComponent.arc", 999);
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void inicializarComponentes() {
        setTitle("Usuarios");
        setSize(450, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        add(panel);

        JLabel usuario = new JLabel("Contraseñas de inicio de sesión");
        usuario.putClientProperty("FlatLaf.style", "font: bold $h2.font");
        usuario.setBounds(77, 20, 300, 25);
        panel.add(usuario);
        

        JLabel Admin = new JLabel("Administrador");
        Admin.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        Admin.setBounds(168, 70, 300, 25);
        panel.add(Admin);
        
        JLabel AdminPass = new JLabel("Contraseña = root");
        AdminPass.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        AdminPass.setBounds(165, 100, 300, 25);
        panel.add(AdminPass);        
        
        JLabel US1 = new JLabel("Usuario 1");
        US1.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        US1.setBounds(187, 140, 300, 25);
        panel.add(US1);
        
        JLabel US1Pass = new JLabel("Contraseña = user1");
        US1Pass.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US1Pass.setBounds(160, 160, 300, 25);
        panel.add(US1Pass);   
        
        JLabel US2 = new JLabel("Usuario 2");
        US2.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        US2.setBounds(187, 200, 300, 25);
        panel.add(US2);
        
        JLabel US2Pass = new JLabel("Contraseña = user2");
        US2Pass.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US2Pass.setBounds(160, 220, 300, 25);
        panel.add(US2Pass); 
        
        JLabel US3 = new JLabel("Usuario 3");
        US3.putClientProperty("FlatLaf.style", "font: bold $h3.font");
        US3.setBounds(187, 260, 300, 25);
        panel.add(US3);
        
        JLabel US3Pass = new JLabel("Contraseña = user3");
        US3Pass.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        US3Pass.setBounds(160, 280, 300, 25);
        panel.add(US3Pass);   
        
        JButton Regresar = new JButton("Regresar");
        Regresar.putClientProperty("FlatLaf.style", "font: bold $h4.font");
        Regresar.setBounds(173, 340, 100, 25);
        panel.add(Regresar);   
        
        Regresar.addActionListener(e -> {
            Usuario newFrame = new Usuario();
            newFrame.setVisible(true);
            dispose();
        });
    }

    
    public static void main(String[] args) {
        System.setProperty( "apple.awt.application.appearance", "system" );
        System.setProperty("apple.awt.application.name", "Conecta y Agenda");

        SwingUtilities.invokeLater(() -> {
            new Default().setVisible(true);
        });
    }
}
