package Modelo;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

public class CustomWebSocketClient extends WebSocketClient {

    public CustomWebSocketClient(URI serverUri) {
        super(serverUri);
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        System.out.println("Conectado al servidor WebSocket");
    }

    @Override
    public void onMessage(String message) {
        System.out.println("Mensaje recibido del servidor: " + message);
        if (message.contains("success")) {
            System.out.println("Compra exitosa recibida. Procesando...");
            // Aquí puedes cerrar la ventana de progreso y mostrar el mensaje de éxito
        } else if (message.contains("cancel")) {
            System.out.println("Compra cancelada recibida.");
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("Conexión cerrada: " + reason);
    }

    @Override
    public void onError(Exception ex) {
        System.out.println("Ocurrió un error: " + ex.getMessage());
    }

    public static void main(String[] args) {
        try {
            URI serverUri = new URI("ws://localhost:3001");
            CustomWebSocketClient client = new CustomWebSocketClient(serverUri);
            client.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
