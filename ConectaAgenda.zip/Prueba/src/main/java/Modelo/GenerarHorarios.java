package Modelo;

import javax.swing.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class GenerarHorarios {

    public List<String> generarHorarios(String horarioEntrada, String horarioSalida, String intervalo) {
        List<String> horarios = new ArrayList<>(); 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); 
        LocalTime entrada = LocalTime.parse(horarioEntrada, formatter);
        LocalTime salida = LocalTime.parse(horarioSalida, formatter);

        int intervalMinutes = 0;
        switch (intervalo) {
            case "15 minutos":
                intervalMinutes = 15;
                break;
            case "30 minutos":
                intervalMinutes = 30;
                break;
            case "45 minutos":
                intervalMinutes = 45;
                break;
            case "1 hora":
                intervalMinutes = 60;
                break;
            case "2 horas":
                intervalMinutes = 120;
                break;
        }

        while (entrada.isBefore(salida) || entrada.equals(salida)) {
            LocalTime fin = entrada.plusMinutes(intervalMinutes); 
            if (fin.isAfter(salida)) { 
                break;
            }
            String horarioInicio = entrada.format(DateTimeFormatter.ofPattern("HH:mm"));
            String horarioFin = fin.format(DateTimeFormatter.ofPattern("HH:mm"));
            horarios.add(horarioInicio + " - " + horarioFin); 
            entrada = fin;
        }

        return horarios; 
    }
    
     public List<JCheckBox> generarHorariosCheck(String horarioEntrada, String horarioSalida, String intervalo) {
        List<JCheckBox> checkBoxes = new ArrayList<>(); 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalTime entrada = LocalTime.parse(horarioEntrada, formatter);
        LocalTime salida = LocalTime.parse(horarioSalida, formatter);

        int intervalMinutes = 0;
        switch (intervalo) {
            case "15 minutos":
                intervalMinutes = 15;
                break;
            case "30 minutos":
                intervalMinutes = 30;
                break;
            case "45 minutos":
                intervalMinutes = 45;
                break;
            case "1 hora":
                intervalMinutes = 60;
                break;
            case "2 horas":
                intervalMinutes = 120;
                break;
        }

        while (entrada.isBefore(salida) || entrada.equals(salida)) {
            LocalTime fin = entrada.plusMinutes(intervalMinutes); 
            if (fin.isAfter(salida)) { 
                break;
            }
            String horarioInicio = entrada.format(DateTimeFormatter.ofPattern("HH:mm"));
            String horarioFin = fin.format(DateTimeFormatter.ofPattern("HH:mm"));
            JCheckBox checkBox = new JCheckBox(horarioInicio + " - " + horarioFin);
            checkBoxes.add(checkBox);
            entrada = fin; 
        }

        return checkBoxes; 
    }
}
