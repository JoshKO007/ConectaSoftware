package Modelo;

import com.formdev.flatlaf.intellijthemes.FlatDarkPurpleIJTheme;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class TemaManager {
    public enum Tema {
        Light, Dark, LightIntellij, DarkDracula, MacOsLight, MacOsDark, LightOrange, OneDark, CyanLight, Solarized
    }
    
    public void aplicarTema(Tema tema) {
        try {
            if (tema == Tema.Light) {
                UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
            } else if (tema == Tema.Dark) {
                UIManager.setLookAndFeel("com.formdev.flatlaf.FlatDarkLaf");
            } else if (tema == Tema.LightIntellij){
                UIManager.setLookAndFeel("com.formdev.flatlaf.FlatIntelliJLaf");
            } else if(tema == Tema.DarkDracula){
                UIManager.setLookAndFeel("com.formdev.flatlaf.FlatDarculaLaf");
            } else if(tema == Tema.MacOsLight){
                UIManager.setLookAndFeel("com.formdev.flatlaf.themes.FlatMacLightLaf");
            } else if(tema == Tema.MacOsDark){
                UIManager.setLookAndFeel("com.formdev.flatlaf.themes.FlatMacDarkLaf");  
            } else if(tema == Tema.LightOrange){
                UIManager.setLookAndFeel("com.formdev.flatlaf.intellijthemes.FlatArcOrangeIJTheme");  
            } else if(tema == Tema.OneDark){
                UIManager.setLookAndFeel("com.formdev.flatlaf.intellijthemes.FlatOneDarkIJTheme");  
            } else if(tema == Tema.CyanLight){
                UIManager.setLookAndFeel("com.formdev.flatlaf.intellijthemes.FlatCyanLightIJTheme");  
            } else if(tema == Tema.Solarized){
                UIManager.setLookAndFeel("com.formdev.flatlaf.intellijthemes.FlatSolarizedLightIJTheme");  
            }
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}
