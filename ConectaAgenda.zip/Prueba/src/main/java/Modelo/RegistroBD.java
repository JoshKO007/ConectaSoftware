package Modelo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;


public class RegistroBD {
    private static final String URL = "jdbc:mysql://localhost:3306/servicios";
    private static final String USER = "root";
    private static final String PASSWORD = "tartara21"; 
    
    
    private Connection connection;

    public RegistroBD() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión a la base de datos establecida.");
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el controlador JDBC: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión a la base de datos cerrada.");
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión a la base de datos: " + e.getMessage());
            }
        }
    }

    public static String hash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString().toUpperCase(); 
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al cifrar con SHA-256: " + e.getMessage());
        }
    }

    public boolean usuarioExiste(String usuario) {
        String query = "SELECT COUNT(*) FROM Usuarios WHERE Usuario = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar el usuario: " + e.getMessage());
        }
        return false;
    }

    public boolean correoExiste(String correo) {
        String query = "SELECT COUNT(*) FROM Usuarios WHERE Correo = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, correo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar el correo electrónico: " + e.getMessage());
        }
        return false;
    }

    public boolean insertarUsuario(String usuario, String correo, String contraseña) {
        if (usuarioExiste(usuario)) {
            System.out.println("El usuario ya existe.");
            return false;
        }
        if (correoExiste(correo)) {
            System.out.println("El correo electrónico ya está registrado.");
            return false;
        }

        String id = hash(usuario);
        String passwordHash = hash(contraseña);

        String query = "INSERT INTO Usuarios (ID, Usuario, Correo, Password) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, id);
            stmt.setString(2, usuario);
            stmt.setString(3, correo);
            stmt.setString(4, passwordHash);
            stmt.executeUpdate();
            System.out.println("Usuario insertado correctamente.");
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar el usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean insertarLicencia(String userID) {
        String query = "INSERT INTO licencias (usuario_id, licencia, fecha_registro) VALUES (?, ?, CURRENT_DATE)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setInt(2, 0); 
            stmt.executeUpdate();
            System.out.println("Licencia insertada correctamente.");
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar la licencia: " + e.getMessage());
            return false;
        }
    }
    
    public boolean insertarSesiones(String userID){
        String query ="INSERT INTO sesiones (id_usuario, contraseñaAdmin, contraseñaUsuario1, contraseñaUsuario2, contraseñaUsuario3) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)){
            stmt.setString(1, userID);
            stmt.setString(2, "root");
            stmt.setString(3, "user1");
            stmt.setString(4, "user2");
            stmt.setString(5, "user3");
            stmt.executeUpdate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public String obtenerID(String usuario) {
        String query = "SELECT ID FROM Usuarios WHERE Usuario = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("ID");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el ID del usuario: " + e.getMessage());
        }
        return null;
    }

    public String obtenerLicencia(String userID) {
    String query = "SELECT licencia FROM licencias WHERE usuario_id = ?";
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, userID);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getString("licencia");
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener la licencia: " + e.getMessage());
    }
        return null;
    }

    public boolean IniciarSesion(String Usuario, String Contraseña) {
        String PassSHA = hash(Contraseña);
        String query = "SELECT COUNT(*) FROM Usuarios WHERE Usuario = ? AND Password = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, Usuario);
            stmt.setString(2, PassSHA);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión: " + e.getMessage());
        }
        return false;
    }
    
    public boolean IniciarAdmin(String Usuario, String Contraseña) {
        String userID = obtenerID(Usuario);
        
        String query = "SELECT COUNT(*) FROM Sesiones WHERE id_usuario = ? AND contraseñaAdmin = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setString(2, Contraseña);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión: " + e.getMessage());
        }
        return false;
    }
    
    public boolean IniciarUsuario1(String Usuario, String Contraseña) {
        String userID = obtenerID(Usuario);
        
        String query = "SELECT COUNT(*) FROM Sesiones WHERE id_usuario = ? AND contraseñaUsuario1 = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setString(2, Contraseña);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión: " + e.getMessage());
        }
        return false;
    }
    
    public boolean IniciarUsuario2(String Usuario, String Contraseña) {
        String userID = obtenerID(Usuario);
        
        String query = "SELECT COUNT(*) FROM Sesiones WHERE id_usuario = ? AND contraseñaUsuario2 = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setString(2, Contraseña);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión: " + e.getMessage());
        }
        return false;
    }    
    
    public boolean IniciarUsuario3(String Usuario, String Contraseña) {
        String userID = obtenerID(Usuario);
        
        String query = "SELECT COUNT(*) FROM Sesiones WHERE id_usuario = ? AND contraseñaUsuario3 = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setString(2, Contraseña);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión: " + e.getMessage());
        }
        return false;
    }    
    
    public boolean insertarNegocio(String nombreNegocio, String tipoNegocio, boolean lunes, boolean martes, boolean miercoles, boolean jueves, boolean viernes, boolean sabado, boolean domingo, String horarioApertura, String horarioCierre, String intervalo, String usuario) {
        String userID = obtenerID(usuario);

        String query = "INSERT INTO negocios (id_usuario, nombre_negocio, tipo_negocio, lunes, martes, miércoles, jueves, viernes, sábado, domingo, horario_apertura, horario_cierre, intervalo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            stmt.setString(2, nombreNegocio);
            stmt.setString(3, tipoNegocio);
            stmt.setBoolean(4, lunes);
            stmt.setBoolean(5, martes);
            stmt.setBoolean(6, miercoles);
            stmt.setBoolean(7, jueves);
            stmt.setBoolean(8, viernes);
            stmt.setBoolean(9, sabado);
            stmt.setBoolean(10, domingo);
            stmt.setTime(11, Time.valueOf(horarioApertura));
            stmt.setTime(12, Time.valueOf(horarioCierre));
            stmt.setString(13, intervalo);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar datos: " + e.getMessage());
            return false;
        }
    }
    
    public boolean usuarioEnNegocios(String userID) {
    String query = "SELECT COUNT(*) FROM negocios WHERE id_usuario = ?";
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, userID);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al verificar el ID del usuario en la tabla de negocios: " + e.getMessage());
    }
    return false;
    }
    
    public boolean registrarPrueba(String usuario) {
    String userID = obtenerID(usuario);
    String querySelect = "SELECT COUNT(*) FROM licencias WHERE usuario_id = ?";
    String queryUpdate = "UPDATE licencias SET licencia = ? WHERE usuario_id = ?";
    
    try (PreparedStatement stmtSelect = connection.prepareStatement(querySelect)) {
        stmtSelect.setString(1, userID);
        
        try (ResultSet rs = stmtSelect.executeQuery()) {
            if (rs.next() && rs.getInt(1) > 0) {
                String nuevaLicencia = userID.substring(0, Math.min(userID.length(), 10)); 
                
                try (PreparedStatement stmtUpdate = connection.prepareStatement(queryUpdate)) {
                    stmtUpdate.setString(1, nuevaLicencia);
                    stmtUpdate.setString(2, userID);
                    stmtUpdate.executeUpdate();
                    System.out.println("Licencia actualizada correctamente.");
                    return true;
                }
            } else {
                System.out.println("El usuario con ID " + userID + " no existe en la tabla licencias.");
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al actualizar la licencia: " + e.getMessage());
    }
    return false;
    }

    public boolean registrarPro(String usuario) {
    String userID = obtenerID(usuario);
    String querySelect = "SELECT COUNT(*) FROM licencias WHERE usuario_id = ?";
    String queryUpdate = "UPDATE licencias SET licencia = ? WHERE usuario_id = ?";
    
    try (PreparedStatement stmtSelect = connection.prepareStatement(querySelect)) {
        stmtSelect.setString(1, userID);
        
        try (ResultSet rs = stmtSelect.executeQuery()) {
            if (rs.next() && rs.getInt(1) > 0) {
                String nuevaLicencia = userID.substring(0, Math.min(userID.length(), 20)); 
                
                try (PreparedStatement stmtUpdate = connection.prepareStatement(queryUpdate)) {
                    stmtUpdate.setString(1, nuevaLicencia);
                    stmtUpdate.setString(2, userID);
                    stmtUpdate.executeUpdate();
                    System.out.println("Licencia actualizada correctamente.");
                    return true;
                }
            } else {
                System.out.println("El usuario con ID " + userID + " no existe en la tabla licencias.");
            }
        }
    } catch (SQLException e) {
        System.out.println("Error al actualizar la licencia: " + e.getMessage());
    }
    return false;
    }
    
    public boolean insertarCliente(String usuario, String nombre, String telefono, String Correo, String Sexo, int edad) {
        String query = "INSERT INTO clientes (usuario_id, Nombre, NumeroTelefono, CorreoElectronico, Sexo, edad) VALUES (?, ?, ?, ?, ?,?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuario);
            stmt.setString(2, nombre);
            stmt.setString(3, telefono);
            stmt.setString(4, Correo);
            stmt.setString(5, Sexo);
            stmt.setInt(6, edad);
            stmt.executeUpdate();
            System.out.println("Cliente insertado correctamente.");
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar el Cliente: " + e.getMessage());
            return false;
        }
    }
    
    public boolean editarCliente(String usuario, String nombreOriginal, String nuevoNombre, String nuevoTelefono, String nuevoCorreo, String nuevoSexo, int edad) {
        String query = "UPDATE clientes SET Nombre = ?, NumeroTelefono = ?, CorreoElectronico = ?, Sexo = ?, edad = ? WHERE usuario_id = ? AND Nombre = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nuevoNombre);
            stmt.setString(2, nuevoTelefono);
            stmt.setString(3, nuevoCorreo);
            stmt.setString(4, nuevoSexo);
            stmt.setInt(5, edad);
            stmt.setString(6, usuario);
            stmt.setString(7, nombreOriginal);

            // Ejecutar la actualización
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Cliente actualizado correctamente.");
                return true;
            } else {
                System.out.println("No se encontró el cliente con el nombre y usuario proporcionados.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el cliente: " + e.getMessage());
            return false;
        }
    }
    
    public boolean guardarClientesEnArchivo(String usuario) throws IOException {
        String query = "SELECT Nombre, NumeroTelefono, CorreoElectronico, Sexo, edad FROM clientes WHERE usuario_id = ?";
        String archivo = "clientes_" + usuario + ".txt";  
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuario);
            try (ResultSet rs = stmt.executeQuery();
                 BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
                
                while (rs.next()) {
                    String nombre = rs.getString("Nombre");
                    String telefono = rs.getString("NumeroTelefono");
                    String correo = rs.getString("CorreoElectronico");
                    String sexo = rs.getString("Sexo");
                    int edad = rs.getInt("edad");

                    String linea = nombre + "," + telefono + "," + correo + "," + sexo + "," + edad;
                    writer.write(linea);
                    writer.newLine();  
                }
                System.out.println("Datos guardados en " + archivo);
                return true;
            } catch (IOException e) {
                System.out.println("Error al escribir en el archivo: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar la base de datos: " + e.getMessage());
        }
        return false;
    }    
    
    public boolean eliminarCliente(String usuario, String nombre, String telefono, String correo, String sexo, int edad) {
    String queryVerificar = "SELECT * FROM clientes WHERE usuario_id = ? AND Nombre = ? AND NumeroTelefono = ? AND CorreoElectronico = ? AND Sexo = ?";
    String queryEliminar = "DELETE FROM clientes WHERE usuario_id = ? AND Nombre = ? AND NumeroTelefono = ? AND CorreoElectronico = ? AND Sexo = ?";

    try (PreparedStatement stmtVerificar = connection.prepareStatement(queryVerificar)) {
        stmtVerificar.setString(1, usuario);
        stmtVerificar.setString(2, nombre);
        stmtVerificar.setString(3, telefono);
        stmtVerificar.setString(4, correo);
        stmtVerificar.setString(5, sexo);

        try (ResultSet rs = stmtVerificar.executeQuery()) {
            if (rs.next()) {
                try (PreparedStatement stmtEliminar = connection.prepareStatement(queryEliminar)) {
                    stmtEliminar.setString(1, usuario);
                    stmtEliminar.setString(2, nombre);
                    stmtEliminar.setString(3, telefono);
                    stmtEliminar.setString(4, correo);
                    stmtEliminar.setString(5, sexo);

                    int rowsDeleted = stmtEliminar.executeUpdate();
                    if (rowsDeleted > 0) {
                        System.out.println("Cliente eliminado correctamente.");
                        return true;  
                    } else {
                        System.out.println("No se pudo eliminar el cliente.");
                        return false;
                    }
                }
            } else {
                System.out.println("No se encontró un cliente que coincida con todos los atributos.");
                return false;  // No se encontró un cliente con esos datos
            }
        }
        } catch (SQLException e) {
        System.out.println("Error al eliminar el cliente: " + e.getMessage());
        return false;
        }
    }

    public String obtenerNombreNegocio(String usuarioId) {
    String query = "SELECT nombre_negocio FROM negocios WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, usuarioId);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String nombreNegocio = rs.getString("nombre_negocio");
                System.out.println("Nombre del negocio encontrado: " + nombreNegocio);
                return nombreNegocio;  
            } else {
                System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                return null; 
            }
        }
        } catch (SQLException e) {
            System.out.println("Error al consultar el negocio: " + e.getMessage());
            return null;
        }
    }
    
    public String obtenerTipoNegocio(String usuarioId) {
    String query = "SELECT tipo_negocio FROM negocios WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, usuarioId);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String tipoNegocio = rs.getString("tipo_negocio");
                System.out.println("Tipo de negocio encontrado: " + tipoNegocio);
                return tipoNegocio;  
            } else {
                System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                return null; 
            }
        }
        } catch (SQLException e) {
            System.out.println("Error al consultar el negocio: " + e.getMessage());
            return null;
        }
    }    
 
    
    public boolean editarNegocio(String nombreNegocio, String tipoNegocio, boolean lunes, boolean martes, boolean miercoles, boolean jueves, boolean viernes, boolean sabado, boolean domingo, String horarioApertura, String horarioCierre, String intervalo, String usuario) {
        String query = "UPDATE negocios SET nombre_negocio = ?, tipo_negocio = ?, lunes = ?, martes = ?, miércoles = ?, jueves = ?, viernes = ?, sábado = ?, domingo = ?, horario_apertura = ?, horario_cierre = ?, intervalo = ? WHERE id_usuario = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nombreNegocio);
            stmt.setString(2, tipoNegocio);
            stmt.setBoolean(3, lunes);
            stmt.setBoolean(4, martes);
            stmt.setBoolean(5, miercoles);
            stmt.setBoolean(6, jueves);
            stmt.setBoolean(7, viernes);
            stmt.setBoolean(8, sabado);
            stmt.setBoolean(9, domingo);
            stmt.setString(10, horarioApertura);
            stmt.setString(11, horarioCierre);
            stmt.setString(12, intervalo);
            stmt.setString(13, usuario);

            // Ejecutar la actualización
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Cliente actualizado correctamente.");
                return true;
            } else {
                System.out.println("No se encontró el cliente con el nombre y usuario proporcionados.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el cliente: " + e.getMessage());
            return false;
        }
    }
    
    public String contraAdmin(String usuarioId) {
    String query = "SELECT contraseñaAdmin FROM sesiones WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, usuarioId);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String contraseña = rs.getString("contraseñaAdmin");
                System.out.println("Contraseña encontrada: " + contraseña);
                return contraseña;  
            } else {
                System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                return null; 
            }
        }
        } catch (SQLException e) {
            System.out.println("Error al consultar el negocio: " + e.getMessage());
            return null;
        }
    }    
    
    public String contraUS1(String usuarioId) {
    String query = "SELECT contraseñaUsuario1 FROM sesiones WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, usuarioId);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String contraseña = rs.getString("contraseñaUsuario1");
                System.out.println("Contraseña encontrada: " + contraseña);
                return contraseña;  
            } else {
                System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                return null; 
            }
        }
        } catch (SQLException e) {
            System.out.println("Error al consultar el negocio: " + e.getMessage());
            return null;
        }
    }   

    public String contraUS2(String usuarioId) {
    String query = "SELECT contraseñaUsuario2 FROM sesiones WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, usuarioId);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String contraseña = rs.getString("contraseñaUsuario2");
                System.out.println("Contraseña encontrada: " + contraseña);
                return contraseña;  
            } else {
                System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                return null; 
            }
        }
        } catch (SQLException e) {
            System.out.println("Error al consultar el negocio: " + e.getMessage());
            return null;
        }
    }   

    public String contraUS3(String usuarioId) {
    String query = "SELECT contraseñaUsuario3 FROM sesiones WHERE id_usuario = ?";
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, usuarioId);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String contraseña = rs.getString("contraseñaUsuario3");
                System.out.println("Contraseña encontrada: " + contraseña);
                return contraseña;  
            } else {
                System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                return null; 
            }
        }
        } catch (SQLException e) {
            System.out.println("Error al consultar el negocio: " + e.getMessage());
            return null;
        }
    }       
    
    public boolean UpdatecontraAdmin(String usuarioId, String nuevaContraseña) {
        String query = "UPDATE sesiones SET contraseñaAdmin = ? WHERE id_usuario = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nuevaContraseña);
            stmt.setString(2, usuarioId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Contraseña actualizada correctamente.");
                return true;
            } else {
                System.out.println("No se encontró el usuario con el ID proporcionado.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar la contraseña: " + e.getMessage());
            return false;
        }
    }
    
    public boolean UpdatecontraUS1(String usuarioId, String nuevaContraseña) {
        String query = "UPDATE sesiones SET contraseñaUsuario1 = ? WHERE id_usuario = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nuevaContraseña);
            stmt.setString(2, usuarioId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Contraseña actualizada correctamente.");
                return true;
            } else {
                System.out.println("No se encontró el usuario con el ID proporcionado.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar la contraseña: " + e.getMessage());
            return false;
        }
    }

    public boolean UpdatecontraUS2(String usuarioId, String nuevaContraseña) {
        String query = "UPDATE sesiones SET contraseñaUsuario2 = ? WHERE id_usuario = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nuevaContraseña);
            stmt.setString(2, usuarioId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Contraseña actualizada correctamente.");
                return true;
            } else {
                System.out.println("No se encontró el usuario con el ID proporcionado.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar la contraseña: " + e.getMessage());
            return false;
        }
    }

    public boolean UpdatecontraUS3(String usuarioId, String nuevaContraseña) {
        String query = "UPDATE sesiones SET contraseñaUsuario3 = ? WHERE id_usuario = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, nuevaContraseña);
            stmt.setString(2, usuarioId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Contraseña actualizada correctamente.");
                return true;
            } else {
                System.out.println("No se encontró el usuario con el ID proporcionado.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar la contraseña: " + e.getMessage());
            return false;
        }
    }
    
    public String obtenerHorarioApertura(String usuarioId) {
        String query = "SELECT horario_apertura FROM negocios WHERE id_usuario = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuarioId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String horarioApertura = rs.getString("horario_apertura");
                    System.out.println("Horario de apertura encontrado: " + horarioApertura);
                    return horarioApertura;  
                } else {
                    System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                    return null; 
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el horario de apertura: " + e.getMessage());
            return null;
        }
    }    

    public String obtenerHorarioCierre(String usuarioId) {
        String query = "SELECT horario_cierre FROM negocios WHERE id_usuario = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuarioId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String horarioCierre = rs.getString("horario_cierre");
                    System.out.println("Horario de cierre encontrado: " + horarioCierre);
                    return horarioCierre;  
                } else {
                    System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                    return null; 
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el horario de cierre: " + e.getMessage());
            return null;
        }
    }

    public String obtenerIntervalo(String usuarioId) {
        String query = "SELECT intervalo FROM negocios WHERE id_usuario = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, usuarioId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String intervalo = rs.getString("intervalo");
                    System.out.println("Intervalo encontrado: " + intervalo);
                    return intervalo;  
                } else {
                    System.out.println("No se encontró un negocio para el usuario con ID: " + usuarioId);
                    return null; 
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar el intervalo: " + e.getMessage());
            return null;
        }
    }
    
    public boolean insertarCita(String idUsuario, String cliente, java.sql.Date fechaCita, java.sql.Time horaCita, String detalleCita, int precioCita, int anticipo) {
        String query = "INSERT INTO Citas (id_usuario, Cliente, Fecha_cita, Hora_cita, Detalle_cita, Precio_cita, Anticipo) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, idUsuario);
            stmt.setString(2, cliente);
            stmt.setDate(3, fechaCita);
            stmt.setTime(4, horaCita);
            stmt.setString(5, detalleCita);
            stmt.setInt(6, precioCita);
            stmt.setInt(7, anticipo);

            stmt.executeUpdate();
            System.out.println("Cita insertada correctamente.");
            return true;
        } catch (SQLException e) {
            System.out.println("Error al insertar la cita: " + e.getMessage());
            return false;
        }
    }

    public ArrayList<String> obtenerHorariosOcupados(String idUsuario, java.sql.Date fechaCita) {
        ArrayList<String> horariosOcupados = new ArrayList<>();
        String query = "SELECT Hora_cita FROM Citas WHERE id_usuario = ? AND Fecha_cita = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, idUsuario);
            stmt.setDate(2, fechaCita);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    horariosOcupados.add(rs.getTime("Hora_cita").toString().substring(0, 5)); // Formato "HH:mm"
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener los horarios ocupados: " + e.getMessage());
        }
        return horariosOcupados;
    } 
    
    public List<String[]> obtenerCitasPorUsuario(String userID) {
        List<String[]> citas = new ArrayList<>();
        String query = "SELECT Cliente, Fecha_cita, Detalle_cita, Precio_cita, Hora_cita, Anticipo FROM citas WHERE id_usuario = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, userID);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String[] cita = new String[6];
                    cita[0] = rs.getString("Cliente"); // Cliente
                    cita[1] = rs.getString("Fecha_cita"); // Fecha
                    cita[2] = rs.getString("Detalle_cita"); // Detalles
                    cita[3] = rs.getString("Precio_cita"); // Precio
                    cita[4] = rs.getString("Hora_cita"); // Hora
                    cita[5] = rs.getString("Anticipo"); // Anticipo
                    citas.add(cita);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener citas: " + e.getMessage());
        }
        return citas;
    }
    
    public static void main(String[] args) {
        RegistroBD dbManager = new RegistroBD();
        dbManager.closeConnection();
    }
}
